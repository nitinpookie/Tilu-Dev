package com.chanit.featuremerger.bridge;

public class FmShim4 extends FmShimBase {
    @Override protected int slot() { return 4; }
}
