package com.chanit.featuremerger;

import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.VpnEnhancer;
import com.chanit.featuremerger.core.VpnFeatures;

import java.util.ArrayList;
import java.util.List;

/** What the Enhance screen and the AI chat screen share: the scanned VPN, the chosen feature, the planned changes, the chat. */
final class EnhanceState {
    private EnhanceState() {}

    static Model.Apk apk;
    static VpnFeatures.Result scan;
    static VpnFeatures.Feat focus;
    static final VpnEnhancer.Plan plan = new VpnEnhancer.Plan();
    static final List<String> notes = new ArrayList<>();
    /** {"user"|"ai", text} */
    static final List<String[]> chat = new ArrayList<>();

    /** A new op replaces an older one for the same thing (same setting, or same component). */
    static void addOps(List<VpnEnhancer.Op> ops) {
        for (VpnEnhancer.Op n : ops) {
            for (int i = plan.ops.size() - 1; i >= 0; i--) {
                VpnEnhancer.Op o = plan.ops.get(i);
                boolean same = n.ctl == null ? (o.ctl == null && o.kind.equals(n.kind))
                        : (o.ctl != null && o.ctl.viewId == n.ctl.viewId && o.ctl.layout.equals(n.ctl.layout));
                if (same) plan.ops.remove(i);
            }
            plan.ops.add(n);
        }
    }

    /** Everything the AI should know about the VPN, in plain text. */
    static String context() {
        StringBuilder sb = new StringBuilder();
        sb.append("VPN app: ").append(apk == null ? "?" : apk.label + " (" + apk.pkg + ")").append('\n');
        if (scan != null) {
            String t = VpnFeatures.text(scan);
            sb.append(t.length() > 4500 ? t.substring(0, 4500) + "\n..." : t).append('\n');
            sb.append("Code facts: addAllowedApplication ").append(scan.calls("addAllowedApplication")).append(", addRoute ").append(scan.calls("addRoute"))
                    .append(", addDnsServer ").append(scan.calls("addDnsServer")).append(", setMtu ").append(scan.calls("setMtu"))
                    .append(", establish ").append(scan.calls("establish")).append('\n');
        } else {
            sb.append("(The VPN has not been scanned yet.)\n");
        }
        if (focus != null) {
            sb.append("Feature the user is looking at: ").append(focus.title).append("  [").append(focus.group).append("]  ").append(focus.detail == null ? "" : focus.detail).append('\n');
            if (!focus.codeRefs.isEmpty()) sb.append("Its code: ").append(focus.codeRefs).append('\n');
        }
        if (!plan.ops.isEmpty()) {
            sb.append("Changes already planned:\n");
            for (VpnEnhancer.Op o : plan.ops) sb.append("- ").append(o.label).append('\n');
        }
        for (String n : notes) sb.append("User note: ").append(n).append('\n');
        return sb.toString();
    }
}
