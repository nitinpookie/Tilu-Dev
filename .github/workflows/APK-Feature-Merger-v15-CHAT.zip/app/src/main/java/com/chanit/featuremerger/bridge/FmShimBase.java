package com.chanit.featuremerger.bridge;

import android.app.Application;
import android.app.Service;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** A real, manifest-declared Service that runs one guest Service object inside the merged app. */
public abstract class FmShimBase extends Service {
    private Service guestSvc;

    protected abstract int slot();

    @Override public void onCreate() {
        super.onCreate();
        try {
            JSONObject f = FmBoot.feature(this, slot());
            if (f == null) {
                stopSelf();
                return;
            }
            FmGuest g = FmBoot.guest(this, f);
            FmGuestContext gc = new FmGuestContext(this, g);
            Class<?> c = g.cl.loadClass(f.getString("service"));
            Constructor<?> k = c.getDeclaredConstructor();
            k.setAccessible(true);
            guestSvc = (Service) k.newInstance();
            Method m = ContextWrapper.class.getDeclaredMethod("attachBaseContext", Context.class);
            m.setAccessible(true);
            m.invoke(guestSvc, gc);
            copyFields(this, guestSvc, g.app != null ? g.app : getApplication());
            FmBoot.setRunning(slot(), true);
            guestSvc.onCreate();
        } catch (Throwable t) {
            Log.e(FmBoot.TAG, "feature " + slot() + " failed to start", t);
            try {
                Toast.makeText(this, "Feature could not start: " + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) { }
            guestSvc = null;
            FmBoot.setRunning(slot(), false);
            stopSelf();
        }
    }

    private static void copyFields(Service from, Service to, Application app) {
        String[] names = {"mThread", "mClassName", "mToken", "mActivityManager", "mApplication"};
        for (String n : names) {
            try {
                Field f = Service.class.getDeclaredField(n);
                f.setAccessible(true);
                f.set(to, "mApplication".equals(n) ? app : f.get(from));
            } catch (Throwable ignored) { }
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (guestSvc == null) return START_NOT_STICKY;
        try {
            return guestSvc.onStartCommand(intent, flags, startId);
        } catch (Throwable t) {
            Log.e(FmBoot.TAG, "onStartCommand", t);
            return START_NOT_STICKY;
        }
    }

    @Override public IBinder onBind(Intent intent) {
        return guestSvc == null ? null : guestSvc.onBind(intent);
    }

    @Override public boolean onUnbind(Intent intent) {
        return guestSvc != null && guestSvc.onUnbind(intent);
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        if (guestSvc != null) guestSvc.onTaskRemoved(rootIntent);
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (guestSvc != null) guestSvc.onConfigurationChanged(c);
    }

    @Override public void onDestroy() {
        try {
            if (guestSvc != null) guestSvc.onDestroy();
        } catch (Throwable t) {
            Log.e(FmBoot.TAG, "onDestroy", t);
        }
        guestSvc = null;
        FmBoot.setRunning(slot(), false);
        super.onDestroy();
    }
}
