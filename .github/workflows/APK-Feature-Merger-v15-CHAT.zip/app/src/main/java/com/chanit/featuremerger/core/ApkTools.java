package com.chanit.featuremerger.core;

import android.content.Context;
import android.graphics.BitmapFactory;

import com.android.tools.smali.dexlib2.iface.ClassDef;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Everything the chat AI can do with the uploaded APKs. Edits are only staged in memory (a session per APK); nothing touches the
 * stored APK until build_apk writes a new, signed file. Every tool returns plain text (errors start with "ERROR:").
 */
public final class ApkTools {
    public interface Host {
        /** A file the user attached in this chat, by its name (null when there is none). */
        File attachment(String name);

        /** Hands a finished file to the chat screen (Save / Share / Install card). */
        void card(File file, String label);

        void progress(String msg);
    }

    private static final class ToolErr extends Exception {
        ToolErr(String m) { super(m); }
    }

    private static final class Session {
        final File src;
        final String id;
        final Map<String, byte[]> files = new LinkedHashMap<>();
        final Set<String> deleted = new LinkedHashSet<>();
        final Map<String, String> smali = new LinkedHashMap<>();
        final Map<String, ClassDef> defs = new LinkedHashMap<>();
        final List<String> log = new ArrayList<>();
        Arsc arsc;
        boolean arscTried;

        Session(File src) {
            this.src = src;
            this.id = idOf(src);
        }

        int edits() { return files.size() + deleted.size() + smali.size(); }
    }

    private final Context ctx;
    private final Store store;
    private final File work;
    private final File outDir;
    private final Map<String, Session> sessions = new HashMap<>();
    private Host host;

    public ApkTools(Context appCtx) {
        this.ctx = appCtx.getApplicationContext();
        this.store = new Store(ctx);
        this.work = new File(ctx.getCacheDir(), "fmwork");
        this.outDir = new File(ctx.getFilesDir(), "chat_out");
        //noinspection ResultOfMethodCallIgnored
        work.mkdirs();
        //noinspection ResultOfMethodCallIgnored
        outDir.mkdirs();
    }

    public void setHost(Host h) { host = h; }

    /** Forgets every staged (not built) edit, used by "New chat". */
    public void clearSessions() { sessions.clear(); }

    public Store store() { return store; }

    public static String idOf(File f) {
        String n = f.getName();
        return n.toLowerCase(Locale.ROOT).endsWith(".apk") ? n.substring(0, n.length() - 4) : n;
    }

    // ------------------------------------------------------------------ what the AI is told about the uploaded APKs
    public String context() {
        File[] fs = apkFiles();
        StringBuilder sb = new StringBuilder();
        if (fs.length == 0) return "Uploaded APKs: none yet.\n";
        sb.append("Uploaded APKs (use the id in tools):\n");
        for (File f : fs) {
            Model.Apk a = info(f);
            Session s = sessions.get(f.getAbsolutePath());
            sb.append("- id ").append(idOf(f)).append(": ").append(a.label).append(" (").append(a.pkg).append(") v").append(a.versionName)
                    .append(", ").append(mb(f.length()));
            if (Xapk.isBundle(ctx.getFilesDir(), idOf(f))) sb.append(", from a bundle (xapk/apks), splits are re-signed on build");
            if (a.vpn) sb.append(", VPN app");
            if (s != null && s.edits() > 0) sb.append(", ").append(s.edits()).append(" edit(s) staged, not built yet");
            sb.append('\n');
        }
        return sb.toString();
    }

    private File[] apkFiles() {
        File[] fs = store.listApks();
        Arrays.sort(fs);
        return fs;
    }

    private Model.Apk info(File f) {
        Model.Apk a = null;
        try { a = store.loadCached(f); } catch (Throwable ignored) { }
        if (a == null) {
            a = ApkAnalyzer.analyze(ctx, f, null);
            try { store.save(a); } catch (Throwable ignored) { }
        }
        return a;
    }

    private static String mb(long n) {
        return n > 1048576 ? String.format(Locale.US, "%.1f MB", n / 1048576.0) : (n / 1024) + " KB";
    }

    private Session session(String ref) throws ToolErr {
        File[] fs = apkFiles();
        if (fs.length == 0) throw new ToolErr("No APK is uploaded yet. Ask the user to upload one with the + button.");
        String r = ref == null ? "" : ref.trim();
        File hit = null;
        if (r.isEmpty() && fs.length == 1) hit = fs[0];
        for (File f : fs) if (hit == null && (f.getName().equalsIgnoreCase(r) || idOf(f).equalsIgnoreCase(r))) hit = f;
        if (hit == null && r.matches("\\d+")) {
            int i = Integer.parseInt(r);
            if (i >= 1 && i <= fs.length) hit = fs[i - 1];
        }
        if (hit == null && !r.isEmpty()) {
            String l = r.toLowerCase(Locale.ROOT);
            for (File f : fs) {
                Model.Apk a = info(f);
                if ((a.pkg != null && a.pkg.toLowerCase(Locale.ROOT).contains(l)) || (a.label != null && a.label.toLowerCase(Locale.ROOT).contains(l))
                        || idOf(f).toLowerCase(Locale.ROOT).contains(l)) {
                    hit = f;
                    break;
                }
            }
        }
        if (hit == null) {
            StringBuilder ids = new StringBuilder();
            for (File f : fs) ids.append(ids.length() > 0 ? ", " : "").append(idOf(f));
            throw new ToolErr("APK \"" + r + "\" not found. Uploaded ids: " + ids);
        }
        Session s = sessions.get(hit.getAbsolutePath());
        if (s == null) {
            s = new Session(hit);
            sessions.put(hit.getAbsolutePath(), s);
        }
        return s;
    }

    // ------------------------------------------------------------------ dispatcher
    public String run(String tool, Map<String, String> a) {
        try {
            String r = dispatch(tool, a);
            return r == null ? "" : r;
        } catch (ToolErr e) {
            return "ERROR: " + e.getMessage();
        } catch (Throwable t) {
            return "ERROR: " + ApkAnalyzer.brief(t);
        } finally {
            File[] fs = work.listFiles();
            if (fs != null) for (File f : fs) //noinspection ResultOfMethodCallIgnored
                f.delete();
        }
    }

    private static String arg(Map<String, String> a, String k) {
        String v = a.get(k);
        return v == null ? "" : v;
    }

    private static int num(Map<String, String> a, String k, int def, int min, int max) {
        try {
            int v = Integer.parseInt(arg(a, k).trim());
            return Math.max(min, Math.min(max, v));
        } catch (Exception e) {
            return def;
        }
    }

    private String dispatch(String tool, Map<String, String> a) throws Exception {
        switch (tool) {
            case "list_apks": return listApks();
            case "apk_info": return apkInfo(session(arg(a, "apk")));
            case "list_files": return listFiles(session(arg(a, "apk")), arg(a, "prefix"), num(a, "max", 120, 10, 300));
            case "read_file": return readFile(session(arg(a, "apk")), arg(a, "path").trim(), num(a, "start", 0, 0, Integer.MAX_VALUE), num(a, "max", 5000, 500, 9000));
            case "list_classes": return listClasses(session(arg(a, "apk")), arg(a, "filter"), num(a, "max", 80, 10, 300));
            case "smali_view": return smaliView(session(arg(a, "apk")), arg(a, "class"), num(a, "start", 0, 0, Integer.MAX_VALUE), num(a, "lines", 120, 20, 300));
            case "find_code": return findCode(session(arg(a, "apk")), arg(a, "text"), arg(a, "package"), num(a, "max", 40, 5, 150));
            case "smali_replace": return smaliReplace(session(arg(a, "apk")), arg(a, "class"), arg(a, "find"), arg(a, "replace"), "true".equalsIgnoreCase(arg(a, "all").trim()));
            case "smali_write": return smaliWrite(session(arg(a, "apk")), arg(a, "class"), arg(a, "text"));
            case "stub_method": return stubMethod(session(arg(a, "apk")), arg(a, "class"), arg(a, "method"), arg(a, "value"));
            case "xml_edit": return xmlEdit(session(arg(a, "apk")), arg(a, "file"), arg(a, "op"), arg(a, "tag"), arg(a, "match"), arg(a, "attr"), arg(a, "value"));
            case "replace_file": return replaceFile(session(arg(a, "apk")), arg(a, "path").trim(), arg(a, "from").trim());
            case "write_file": return writeFile(session(arg(a, "apk")), arg(a, "path").trim(), arg(a, "text"));
            case "delete_file": return deleteFile(session(arg(a, "apk")), arg(a, "path").trim());
            case "changes": return changes(session(arg(a, "apk")));
            case "reset_edits": return reset(session(arg(a, "apk")));
            case "extract_source": return extractSource(session(arg(a, "apk")), arg(a, "package"));
            case "build_apk": return build(session(arg(a, "apk")), !"false".equalsIgnoreCase(arg(a, "sign").trim()));
            case "read_attachment": return readAttachment(arg(a, "name").trim(), num(a, "start", 0, 0, Integer.MAX_VALUE));
            default: throw new ToolErr("Unknown tool \"" + tool + "\".");
        }
    }

    /** Short label for the chat screen ("Reading AndroidManifest.xml"). */
    public static String label(String tool, Map<String, String> a) {
        String p = arg(a, "path"), c = arg(a, "class");
        switch (tool) {
            case "list_apks": return "Checking the uploaded APKs";
            case "apk_info": return "Reading app info";
            case "list_files": return "Listing files" + (p.isEmpty() && arg(a, "prefix").isEmpty() ? "" : " in " + arg(a, "prefix"));
            case "read_file": return "Reading " + p;
            case "list_classes": return "Listing classes" + (arg(a, "filter").isEmpty() ? "" : " (" + arg(a, "filter") + ")");
            case "smali_view": return "Reading code of " + SmaliTool.dotted(SmaliTool.type(c));
            case "find_code": return "Searching the code for \"" + arg(a, "text") + "\"";
            case "smali_replace": case "smali_write": return "Editing code of " + SmaliTool.dotted(SmaliTool.type(c));
            case "stub_method": return "Changing method " + arg(a, "method");
            case "xml_edit": return "Editing " + (arg(a, "file").isEmpty() ? "AndroidManifest.xml" : arg(a, "file"));
            case "replace_file": return "Replacing " + p;
            case "write_file": return "Writing " + p;
            case "delete_file": return "Removing " + p;
            case "changes": return "Checking the staged edits";
            case "reset_edits": return "Discarding the staged edits";
            case "extract_source": return "Extracting the source (smali + decoded XML)";
            case "build_apk": return "Building and signing the APK";
            case "read_attachment": return "Reading " + arg(a, "name");
            default: return tool;
        }
    }

    private static String cap(String s, int max) {
        if (s.length() <= max) return s;
        return s.substring(0, max) + "\n...[cut, " + (s.length() - max) + " more characters]";
    }

    // ------------------------------------------------------------------ read-only tools
    private String listApks() {
        String c = context();
        return c.startsWith("Uploaded APKs: none") ? "No APK uploaded yet." : c;
    }

    private String apkInfo(Session s) throws Exception {
        Model.Apk m = info(s.src);
        StringBuilder sb = new StringBuilder();
        sb.append("id ").append(s.id).append(": ").append(m.label).append(" (").append(m.pkg).append(") v").append(m.versionName).append(" code ").append(m.versionCode)
                .append("\nsize ").append(mb(s.src.length())).append(", minSdk ").append(m.minSdk).append(", targetSdk ").append(m.targetSdk)
                .append(", dex files ").append(m.dexCount).append(", classes ").append(m.classCount).append(", abis ").append(m.abis).append('\n');
        if (!m.permissions.isEmpty()) sb.append("permissions (").append(m.permissions.size()).append("): ").append(cap(String.valueOf(m.permissions), 900)).append('\n');
        for (String n : m.notes) sb.append("note: ").append(n).append('\n');
        try (ZipFile zf = new ZipFile(s.src)) {
            Map<String, int[]> top = new TreeMap<>();
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String n = e.getName();
                int i = n.indexOf('/');
                String k = i < 0 ? "(root files)" : n.substring(0, i + 1);
                int[] c = top.get(k);
                if (c == null) top.put(k, c = new int[1]);
                c[0]++;
            }
            sb.append("zip: ");
            for (Map.Entry<String, int[]> e : top.entrySet()) sb.append(e.getKey()).append(' ').append(e.getValue()[0]).append("  ");
            sb.append('\n');
        }
        byte[] man = bytes(s, "AndroidManifest.xml");
        Axml ax = Axml.parse(man);
        Axml.Elem app = ax.root.child("application");
        if (app != null) {
            sb.append("application: label=").append(app.text("label")).append(" debuggable=").append(app.text("debuggable")).append(" allowBackup=").append(app.text("allowBackup"))
                    .append(" class=").append(app.text("name")).append('\n');
            for (String tag : new String[]{"activity", "service", "receiver", "provider"}) {
                StringBuilder names = new StringBuilder();
                int n = 0;
                for (Axml.Elem k : app.kids) {
                    if (!tag.equals(k.name)) continue;
                    if (n++ < 25) names.append(names.length() > 0 ? ", " : "").append(k.text("name"));
                }
                if (n > 0) sb.append(tag).append("s (").append(n).append("): ").append(names).append(n > 25 ? ", ..." : "").append('\n');
            }
        }
        if (s.edits() > 0) sb.append(s.edits()).append(" staged edit(s): use changes\n");
        return sb.toString();
    }

    private Set<String> entryNames(Session s, Map<String, Long> sizes) throws IOException {
        Set<String> names = new LinkedHashSet<>();
        try (ZipFile zf = new ZipFile(s.src)) {
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory() || s.deleted.contains(e.getName())) continue;
                names.add(e.getName());
                sizes.put(e.getName(), e.getSize());
            }
        }
        for (Map.Entry<String, byte[]> e : s.files.entrySet()) {
            names.add(e.getKey());
            sizes.put(e.getKey(), (long) e.getValue().length);
        }
        return names;
    }

    private String listFiles(Session s, String prefix, int max) throws Exception {
        Map<String, Long> sizes = new HashMap<>();
        List<String> names = new ArrayList<>(entryNames(s, sizes));
        Collections.sort(names);
        String p = prefix.trim();
        StringBuilder sb = new StringBuilder();
        if (p.isEmpty() && names.size() > max) {
            Map<String, long[]> top = new TreeMap<>();
            for (String n : names) {
                int i = n.indexOf('/');
                String k = i < 0 ? n : n.substring(0, i + 1);
                long[] c = top.get(k);
                if (c == null) top.put(k, c = new long[2]);
                c[0]++;
                c[1] += Math.max(0, sizes.get(n));
            }
            sb.append(names.size()).append(" files. Top level (give prefix=<folder>/ to look inside):\n");
            for (Map.Entry<String, long[]> e : top.entrySet())
                sb.append(e.getKey()).append(e.getValue()[0] > 1 || e.getKey().endsWith("/") ? "  " + e.getValue()[0] + " file(s), " + mb(e.getValue()[1]) : "  " + mb(e.getValue()[1])).append('\n');
            return sb.toString();
        }
        int shown = 0, total = 0;
        for (String n : names) {
            if (!p.isEmpty() && !n.startsWith(p)) continue;
            total++;
            if (shown >= max) continue;
            shown++;
            sb.append(n).append("  ").append(mb(Math.max(0, sizes.get(n))));
            if (s.files.containsKey(n)) sb.append("  (edited)");
            sb.append('\n');
        }
        if (total == 0) return "No files start with \"" + p + "\".";
        if (total > shown) sb.append("... ").append(total - shown).append(" more, narrow the prefix\n");
        for (String d : s.deleted) if (p.isEmpty() || d.startsWith(p)) sb.append("(deleted: ").append(d).append(")\n");
        return sb.toString();
    }

    private byte[] bytes(Session s, String name) throws IOException, ToolErr {
        if (s.deleted.contains(name)) throw new ToolErr(name + " was deleted in this session.");
        byte[] st = s.files.get(name);
        if (st != null) return st;
        try (ZipFile zf = new ZipFile(s.src)) {
            ZipEntry e = zf.getEntry(name);
            if (e == null) throw new ToolErr("No file \"" + name + "\" in the APK. Use list_files.");
            if (e.getSize() > 48L * 1024 * 1024) throw new ToolErr(name + " is too big (" + mb(e.getSize()) + ") to open here.");
            return ApkZip.readAll(zf, e);
        }
    }

    private static boolean isBinaryXml(byte[] b) {
        return b.length > 8 && b[0] == 0x03 && b[1] == 0x00 && b[2] == 0x08 && b[3] == 0x00;
    }

    private static boolean looksText(byte[] b) {
        int n = Math.min(b.length, 4096), bad = 0;
        for (int i = 0; i < n; i++) {
            int c = b[i] & 0xff;
            if (c == 0) return false;
            if (c < 9 || (c > 13 && c < 32)) bad++;
        }
        return n == 0 || bad * 50 < n;
    }

    private Arsc arsc(Session s) {
        if (s.arscTried) return s.arsc;
        s.arscTried = true;
        try (ZipFile zf = new ZipFile(s.src)) {
            ZipEntry e = zf.getEntry("resources.arsc");
            if (e != null && e.getSize() < 40L * 1024 * 1024) s.arsc = Arsc.parse(ApkZip.readAll(zf, e));
        } catch (Throwable ignored) { }
        return s.arsc;
    }

    private String readFile(Session s, String path, int start, int max) throws Exception {
        if (path.isEmpty()) throw new ToolErr("path is empty");
        byte[] b = bytes(s, path);
        String text;
        String kind;
        if (path.equals("resources.arsc")) {
            Arsc a = arsc(s);
            if (a == null) throw new ToolErr("resources.arsc could not be read");
            List<Arsc.Entry> es = new ArrayList<>(a.byId.values());
            Collections.sort(es, (x, y) -> Integer.compare(x.id, y.id));
            StringBuilder sb = new StringBuilder();
            for (Arsc.Entry e : es) {
                if (e.strings.isEmpty() || e.type == null) continue;
                String v = e.strings.get(0) == null ? "" : e.strings.get(0).replace("\n", "\\n");
                sb.append(e.type).append('/').append(e.name).append(" = ").append(v.length() > 160 ? v.substring(0, 160) + "..." : v).append('\n');
            }
            text = sb.toString();
            kind = "resource table (type/name = first value)";
        } else if (isBinaryXml(b)) {
            text = AxmlText.toXml(b, arsc(s));
            kind = "binary XML shown as text";
        } else if (looksText(b)) {
            text = new String(b, "UTF-8");
            kind = "text";
        } else {
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < Math.min(48, b.length); i++) hex.append(String.format("%02x", b[i] & 0xff));
            String extra = "";
            String l = path.toLowerCase(Locale.ROOT);
            if (l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".webp")) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(b, 0, b.length, o);
                extra = ", image " + o.outWidth + "x" + o.outHeight;
            }
            return path + ": binary file, " + b.length + " bytes" + extra + ". First bytes: " + hex;
        }
        if (start >= text.length()) return path + ": end of file (" + text.length() + " characters).";
        int end = Math.min(text.length(), start + max);
        String more = end < text.length() ? "\n...[continue with start=" + end + "]" : "";
        return "[" + path + " - " + kind + " - characters " + start + "-" + end + " of " + text.length() + "]\n" + text.substring(start, end) + more;
    }

    private String listClasses(Session s, String filter, int max) throws Exception {
        List<SmaliTool.Dex> dexes = SmaliTool.openDex(s.src, work);
        try {
            int[] count = new int[1];
            List<String> cl = SmaliTool.classes(dexes, filter, max, count);
            StringBuilder sb = new StringBuilder(count[0] + " class(es)" + (filter.isEmpty() ? "" : " matching \"" + filter + "\"") + (count[0] > cl.size() ? ", showing " + cl.size() : "") + ":\n");
            for (String c : cl) sb.append(c).append('\n');
            for (String t : s.smali.keySet()) sb.append("(edited) ").append(SmaliTool.dotted(t)).append('\n');
            return sb.toString();
        } finally {
            SmaliTool.cleanup(dexes);
        }
    }

    /** Smali of a class: the staged version when it was edited, else the one from the dex files. */
    private String currentSmali(Session s, List<SmaliTool.Dex> dexes, String type) throws Exception {
        String st = s.smali.get(type);
        if (st != null) return st;
        ClassDef cd = SmaliTool.find(dexes, type);
        if (cd == null) throw new ToolErr("Class " + SmaliTool.dotted(type) + " not found. Use list_classes with part of its name.");
        return SmaliTool.smaliOf(cd);
    }

    private String smaliView(Session s, String cls, int start, int lines) throws Exception {
        if (cls.trim().isEmpty()) throw new ToolErr("class is empty");
        String type = SmaliTool.type(cls);
        List<SmaliTool.Dex> dexes = SmaliTool.openDex(s.src, work);
        try {
            String text = currentSmali(s, dexes, type);
            String[] ln = text.split("\n", -1);
            if (start >= ln.length) return "End of class (" + ln.length + " lines).";
            int end = Math.min(ln.length, start + lines);
            StringBuilder sb = new StringBuilder("[" + SmaliTool.dotted(type) + (s.smali.containsKey(type) ? " (edited)" : "") + " - lines " + start + "-" + end + " of " + ln.length + "]\n");
            for (int i = start; i < end; i++) sb.append(ln[i]).append('\n');
            if (end < ln.length) sb.append("...[continue with start=").append(end).append("]\n");
            return cap(sb.toString(), 10000);
        } finally {
            SmaliTool.cleanup(dexes);
        }
    }

    private String findCode(Session s, String text, String pkg, int max) throws Exception {
        if (text.trim().isEmpty()) throw new ToolErr("text is empty");
        List<SmaliTool.Dex> dexes = SmaliTool.openDex(s.src, work);
        try {
            boolean[] cut = new boolean[1];
            List<String> hits = SmaliTool.findCode(dexes, text.trim(), pkg, max, cut);
            if (hits.isEmpty()) return "No match for \"" + text + "\" in strings, calls, fields or class names" + (pkg.isEmpty() ? "." : " under " + pkg + ".");
            StringBuilder sb = new StringBuilder(hits.size() + " match(es)" + (cut[0] ? " (more exist, narrow it with package=)" : "") + ":\n");
            for (String h : hits) sb.append(h).append('\n');
            return cap(sb.toString(), 9000);
        } finally {
            SmaliTool.cleanup(dexes);
        }
    }

    private String readAttachment(String name, int start) throws Exception {
        File f = host == null ? null : host.attachment(name);
        if (f == null) throw new ToolErr("No attached file named \"" + name + "\".");
        byte[] b = ApkZip.readFile(f);
        if (!looksText(b)) return name + ": binary file, " + b.length + " bytes.";
        String t = new String(b, "UTF-8");
        if (start >= t.length()) return "End of file.";
        int end = Math.min(t.length(), start + 6000);
        return t.substring(start, end) + (end < t.length() ? "\n...[continue with start=" + end + "]" : "");
    }

    // ------------------------------------------------------------------ editing tools (staged)
    private String stageSmali(Session s, String type, String text, String what) throws Exception {
        ClassDef cd = SmaliTool.assemble(work, text); // validates the text; throws with the assembler's messages
        if (!cd.getType().equals(type)) throw new ToolErr("The .class line says " + SmaliTool.dotted(cd.getType()) + " but the tool call is for " + SmaliTool.dotted(type) + ".");
        s.smali.put(type, text);
        s.defs.put(type, cd);
        s.log.add(what);
        return "OK, " + what + ". The class assembles fine. Staged (not built yet).";
    }

    private String smaliReplace(Session s, String cls, String find, String repl, boolean all) throws Exception {
        if (find.isEmpty()) throw new ToolErr("find is empty");
        String type = SmaliTool.type(cls);
        List<SmaliTool.Dex> dexes = SmaliTool.openDex(s.src, work);
        String text;
        try {
            text = currentSmali(s, dexes, type);
        } finally {
            SmaliTool.cleanup(dexes);
        }
        int n = 0, from = 0;
        while ((from = text.indexOf(find, from)) >= 0) {
            n++;
            from += find.length();
        }
        if (n == 0) {
            String first = find.trim().split("\n")[0].trim();
            String hint = "";
            if (!first.isEmpty()) {
                int i = text.indexOf(first);
                if (i >= 0) hint = " The first line of find exists at: " + text.substring(Math.max(0, text.lastIndexOf('\n', i)), Math.min(text.length(), text.indexOf('\n', i + first.length() + 1) < 0 ? text.length() : text.indexOf('\n', i + first.length() + 1))).trim() + " (check indentation and the lines after it).";
            }
            throw new ToolErr("find text not found in " + SmaliTool.dotted(type) + "; it must match smali_view exactly (spaces, registers)." + hint);
        }
        if (n > 1 && !all) throw new ToolErr("find text occurs " + n + " times. Make it longer so it is unique, or pass all=true.");
        String out = all ? text.replace(find, repl) : text.replaceFirst(java.util.regex.Pattern.quote(find), java.util.regex.Matcher.quoteReplacement(repl));
        return stageSmali(s, type, out, "replaced " + n + " place(s) in " + SmaliTool.dotted(type));
    }

    private String smaliWrite(Session s, String cls, String text) throws Exception {
        if (text.trim().isEmpty()) throw new ToolErr("text is empty");
        String type = cls.trim().isEmpty() ? null : SmaliTool.type(cls);
        if (type == null) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?m)^\\.class\\b.*?(L[^;\\s]+;)").matcher(text);
            if (!m.find()) throw new ToolErr("no .class line in text");
            type = m.group(1);
        }
        return stageSmali(s, type, text, "wrote the whole class " + SmaliTool.dotted(type));
    }

    private String stubMethod(Session s, String cls, String method, String value) throws Exception {
        if (cls.trim().isEmpty() || method.trim().isEmpty()) throw new ToolErr("class and method are required");
        String type = SmaliTool.type(cls);
        List<SmaliTool.Dex> dexes = SmaliTool.openDex(s.src, work);
        String text;
        try {
            text = currentSmali(s, dexes, type);
        } finally {
            SmaliTool.cleanup(dexes);
        }
        String out = SmaliTool.stubMethod(text, method.trim(), value);
        return stageSmali(s, type, out, "method " + method.trim() + " in " + SmaliTool.dotted(type) + " now only returns " + (value.trim().isEmpty() ? "nothing/false/null" : value.trim()));
    }

    private String xmlEdit(Session s, String file, String op, String tag, String match, String attr, String value) throws Exception {
        String f = file.trim().isEmpty() ? "AndroidManifest.xml" : file.trim();
        byte[] b = bytes(s, f);
        if (!isBinaryXml(b)) throw new ToolErr(f + " is not a binary XML file.");
        AxmlText.Result r;
        try {
            r = AxmlText.apply(b, op.trim(), tag.trim(), match.trim(), attr.trim(), value);
        } catch (IllegalArgumentException e) {
            throw new ToolErr(e.getMessage());
        }
        if (r.changed == 0 || r.out == null) {
            final Set<String> tags = new LinkedHashSet<>();
            Axml.parse(b).root.walk(new Axml.Visitor() {
                @Override public void visit(Axml.Elem e) { if (tags.size() < 25) tags.add(e.name); }
            });
            throw new ToolErr("Nothing matched" + (r.note.isEmpty() ? "" : " (" + r.note + ")") + ". Tags in this file: " + tags + ". tag/match must name an existing element; match is a part of android:name.");
        }
        Axml.parse(r.out); // must parse again
        s.files.put(f, r.out);
        String what = op.trim() + " in " + f + " (" + r.changed + " place(s))";
        s.log.add(what);
        return "OK, " + what + ". Staged (not built yet).";
    }

    private static boolean protectedName(String n) {
        return n.equals("AndroidManifest.xml") || n.equals("resources.arsc") || n.matches("classes\\d*\\.dex");
    }

    private String replaceFile(Session s, String path, String from) throws Exception {
        if (path.isEmpty() || from.isEmpty()) throw new ToolErr("path and from (attachment name) are required");
        if (protectedName(path)) throw new ToolErr(path + " cannot be replaced with a file; use xml_edit / smali tools.");
        File f = host == null ? null : host.attachment(from);
        if (f == null) throw new ToolErr("No attached file named \"" + from + "\". The user must attach it first.");
        if (f.length() > 40L * 1024 * 1024) throw new ToolErr("attachment too big");
        byte[] b = ApkZip.readFile(f);
        if (path.startsWith("res/") && path.endsWith(".xml") && !isBinaryXml(b)) throw new ToolErr("res/ XML files must be binary XML; a plain text XML would break the app. Use xml_edit instead.");
        s.deleted.remove(path);
        s.files.put(path, b);
        String what = "replaced " + path + " with " + from + " (" + mb(b.length) + ")";
        s.log.add(what);
        return "OK, " + what + ". Staged.";
    }

    private String writeFile(Session s, String path, String text) throws Exception {
        if (path.isEmpty()) throw new ToolErr("path is empty");
        if (protectedName(path)) throw new ToolErr(path + " cannot be written as text.");
        if (path.startsWith("res/") && !path.startsWith("res/raw/")) throw new ToolErr("Files under res/ (except res/raw/) are compiled resources; write_file only works for assets/, res/raw/ and other plain files.");
        s.deleted.remove(path);
        s.files.put(path, text.getBytes("UTF-8"));
        String what = "wrote " + path + " (" + text.length() + " characters)";
        s.log.add(what);
        return "OK, " + what + ". Staged.";
    }

    private String deleteFile(Session s, String path) throws Exception {
        if (path.isEmpty()) throw new ToolErr("path is empty");
        if (protectedName(path)) throw new ToolErr(path + " cannot be deleted.");
        Map<String, Long> sizes = new HashMap<>();
        int n = 0;
        for (String name : new ArrayList<>(entryNames(s, sizes))) {
            if (protectedName(name)) continue;
            if (name.equals(path) || (path.endsWith("/") && name.startsWith(path))) {
                s.files.remove(name);
                s.deleted.add(name);
                n++;
            }
        }
        if (n == 0) throw new ToolErr("No file \"" + path + "\" (for a folder end the path with /).");
        String what = "deleted " + n + " file(s) under " + path;
        s.log.add(what);
        return "OK, " + what + ". Staged.";
    }

    private String changes(Session s) {
        if (s.log.isEmpty()) return "No staged edits for " + s.id + ".";
        StringBuilder sb = new StringBuilder("Staged for " + s.id + ":\n");
        for (String l : s.log) sb.append("- ").append(l).append('\n');
        return sb.toString();
    }

    private String reset(Session s) {
        s.files.clear();
        s.deleted.clear();
        s.smali.clear();
        s.defs.clear();
        s.log.clear();
        return "All staged edits of " + s.id + " were discarded.";
    }

    // ------------------------------------------------------------------ source extractor (the jadx / apktool style export)
    private String extractSource(Session s, String pkg) throws Exception {
        File out = new File(outDir, s.id + "_source.zip");
        int classes = 0, xml = 0, failed = 0;
        List<SmaliTool.Dex> dexes = SmaliTool.openDex(s.src, work);
        try (ZipOutputStream zo = new ZipOutputStream(new FileOutputStream(out))) {
            String pre = pkg.trim().toLowerCase(Locale.ROOT);
            for (SmaliTool.Dex d : dexes) {
                for (ClassDef cd : d.df.getClasses()) {
                    String dn = SmaliTool.dotted(cd.getType());
                    if (!pre.isEmpty() && !dn.toLowerCase(Locale.ROOT).startsWith(pre)) continue;
                    try {
                        String sm = s.smali.containsKey(cd.getType()) ? s.smali.get(cd.getType()) : SmaliTool.smaliOf(cd);
                        put(zo, "smali/" + d.entry.replace(".dex", "") + "/" + dn.replace('.', '/') + ".smali", sm.getBytes("UTF-8"));
                        classes++;
                    } catch (Throwable t) {
                        failed++;
                    }
                    if (classes % 1000 == 0 && host != null) host.progress("Extracting source: " + classes + " classes done");
                }
            }
            Arsc a = arsc(s);
            try (ZipFile zf = new ZipFile(s.src)) {
                StringBuilder files = new StringBuilder();
                for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                    ZipEntry e = en.nextElement();
                    if (e.isDirectory()) continue;
                    files.append(e.getName()).append("  ").append(e.getSize()).append('\n');
                    String n = e.getName();
                    if (n.endsWith(".xml") && (n.startsWith("res/") || n.equals("AndroidManifest.xml")) && e.getSize() < 4L * 1024 * 1024) {
                        try {
                            byte[] b = ApkZip.readAll(zf, e);
                            if (isBinaryXml(b)) {
                                put(zo, "decoded/" + n, AxmlText.toXml(b, a).getBytes("UTF-8"));
                                xml++;
                            }
                        } catch (Throwable t) {
                            failed++;
                        }
                    } else if ((n.startsWith("assets/") || n.startsWith("res/raw/")) && e.getSize() < 256 * 1024) {
                        try {
                            byte[] b = ApkZip.readAll(zf, e);
                            if (looksText(b)) put(zo, "text_files/" + n, b);
                        } catch (Throwable ignored) { }
                    }
                }
                put(zo, "files.txt", files.toString().getBytes("UTF-8"));
            }
            if (a != null) {
                StringBuilder sb = new StringBuilder();
                List<Arsc.Entry> es = new ArrayList<>(a.byId.values());
                Collections.sort(es, (x, y) -> Integer.compare(x.id, y.id));
                for (Arsc.Entry e : es) {
                    if (e.strings.isEmpty() || e.type == null) continue;
                    sb.append(String.format("0x%08x ", e.id)).append(e.type).append('/').append(e.name).append(" = ").append(String.valueOf(e.strings.get(0)).replace("\n", "\\n")).append('\n');
                }
                put(zo, "resources_table.txt", sb.toString().getBytes("UTF-8"));
            }
            put(zo, "README.txt", ("Source export of " + s.id + " made by Feature Merger.\nsmali/ = every class as smali (apktool style, can be edited and put back with the chat tools)\n"
                    + "decoded/ = AndroidManifest.xml and res/**.xml as readable text\nresources_table.txt = resource names and values\nfiles.txt = every file of the APK\n"
                    + "text_files/ = small text files from assets and res/raw\nJava source (jadx style) is not produced on the phone; smali is the exact code.\n").getBytes("UTF-8"));
        } finally {
            SmaliTool.cleanup(dexes);
        }
        if (host != null) host.card(out, s.id + "_source.zip");
        return "Source extracted: " + classes + " class(es) as smali, " + xml + " XML file(s) decoded" + (failed > 0 ? ", " + failed + " item(s) skipped" : "") + ". The zip (" + mb(out.length()) + ") is shown to the user as a file card with Save and Share.";
    }

    private static void put(ZipOutputStream zo, String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        zo.putNextEntry(e);
        zo.write(data);
        zo.closeEntry();
    }

    // ------------------------------------------------------------------ build
    private String build(Session s, boolean sign) throws Exception {
        if (s.edits() == 0) throw new ToolErr("Nothing is staged for " + s.id + ". Make an edit first.");
        boolean bundle = Xapk.isBundle(ctx.getFilesDir(), s.id);
        if (bundle) sign = true; // splits must carry the same signature as the base
        Map<String, byte[]> replace = new LinkedHashMap<>();
        Set<String> origNames = new HashSet<>();
        try (ZipFile zf = new ZipFile(s.src)) {
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) origNames.add(en.nextElement().getName());
        }
        if (!s.defs.isEmpty()) {
            List<SmaliTool.Dex> dexes = SmaliTool.openDex(s.src, work);
            try {
                if (host != null) host.progress("Writing the changed classes into the dex files");
                replace.putAll(SmaliTool.rewrite(dexes, s.defs, new HashSet<String>(), work));
            } finally {
                SmaliTool.cleanup(dexes);
            }
        }
        File unsigned = new File(work, "unsigned.apk");
        try (ApkZip.Writer w = new ApkZip.Writer(unsigned)) {
            for (String d : s.deleted) w.skip(d);
            for (Map.Entry<String, byte[]> e : s.files.entrySet()) {
                if (origNames.contains(e.getKey())) replace.put(e.getKey(), e.getValue());
                else w.put(e.getKey(), e.getValue(), false);
            }
            w.copy(s.src, replace, null, true);
        }
        String base = s.id + "_edited";
        File signed = uniqueOut(base + ".apk");
        if (sign) {
            if (host != null) host.progress("Signing");
            Signer.sign(new File(ctx.getFilesDir(), "keys"), unsigned, signed);
            //noinspection ResultOfMethodCallIgnored
            unsigned.delete();
        } else {
            if (!unsigned.renameTo(signed)) throw new ToolErr("could not write the output file");
        }
        StringBuilder rep = new StringBuilder();
        String verify = verify(signed, s);
        File deliver = signed;
        if (bundle) {
            File dir = Xapk.dir(ctx.getFilesDir(), s.id);
            String bp = Xapk.basePath(dir);
            if (bp == null) throw new ToolErr("The bundle folder has no base APK any more.");
            deliver = uniqueOut(base + ".xapk");
            if (host != null) host.progress("Re-signing the split APKs and packing the bundle");
            int n = Xapk.repack(dir, bp, signed, new File(ctx.getFilesDir(), "keys"), deliver, work);
            rep.append("Bundle packed: base edited, ").append(n).append(" split APK(s) re-signed with the same key. Install it with an XAPK/APKS installer (Android cannot open .xapk itself).\n");
            //noinspection ResultOfMethodCallIgnored
            signed.delete();
        }
        if (host != null) host.card(deliver, deliver.getName());
        rep.insert(0, "Built " + deliver.getName() + " (" + mb(deliver.length()) + ")" + (sign ? ", signed v1+v2 with the Feature Merger key" : ", UNSIGNED (sign it with MT Manager)") + ".\n");
        rep.append("Check: ").append(verify).append('\n');
        rep.append("Edits included: ").append(s.log.size()).append(". The user sees a file card with Save / Share").append(bundle ? "" : " / Install").append(" under your message.\n");
        if (sign) rep.append("Reminder to tell the user: the signature differs from the original app, so the original must be uninstalled first (its data is lost), and apps that check their own signature may refuse to start.\n");
        return rep.toString();
    }

    private File uniqueOut(String name) {
        File f = new File(outDir, name);
        String stem = name.substring(0, name.lastIndexOf('.')), ext = name.substring(name.lastIndexOf('.'));
        int i = 2;
        while (f.exists()) f = new File(outDir, stem + "_" + (i++) + ext);
        return f;
    }

    private String verify(File apk, Session s) {
        try (ZipFile zf = new ZipFile(apk)) {
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me == null) return "FAILED: the APK has no AndroidManifest.xml";
            Axml.parse(ApkZip.readAll(zf, me));
        } catch (Throwable t) {
            return "FAILED: " + ApkAnalyzer.brief(t);
        }
        List<SmaliTool.Dex> dexes = null;
        try {
            dexes = SmaliTool.openDex(apk, work);
            int n = 0;
            for (SmaliTool.Dex d : dexes) for (ClassDef ignored : d.df.getClasses()) n++;
            for (String t : s.defs.keySet()) if (SmaliTool.find(dexes, t) == null) return "FAILED: edited class " + SmaliTool.dotted(t) + " is missing in the output dex";
            return "zip, manifest and " + dexes.size() + " dex file(s) with " + n + " classes read back fine; " + s.defs.size() + " edited class(es) present.";
        } catch (Throwable t) {
            return "FAILED: " + ApkAnalyzer.brief(t);
        } finally {
            if (dexes != null) SmaliTool.cleanup(dexes);
        }
    }

    // ------------------------------------------------------------------ the tool list the AI is given
    public static final String DOCS =
            "TOOLS (apk = id of an uploaded APK; string arguments, no quotes needed):\n"
                    + "list_apks | apk_info(apk) | list_files(apk, prefix?, max?) | read_file(apk, path, start?, max?) - text files, binary XML (manifest, layouts) is shown as text, resources.arsc as a name/value table\n"
                    + "list_classes(apk, filter?, max?) | smali_view(apk, class, start?, lines?) - smali of a class (dotted name or Lpkg/Name;)\n"
                    + "find_code(apk, text, package?, max?) - finds strings, method calls, field uses and class names in the code\n"
                    + "smali_replace(apk, class, find, replace, all?) - exact text replace in the class smali, the class is re-assembled to check it\n"
                    + "smali_write(apk, class?, text) - whole smali class (new or changed) | stub_method(apk, class, method, value) - method only returns void/true/false/null/number\n"
                    + "xml_edit(apk, file?, op, tag, match, attr, value) - binary XML (default AndroidManifest.xml). op: set_attr | remove_attr | remove_element | replace_text (attr = old text, value = new text). "
                    + "tag = element name or *, match = part of its android:name. set_attr supports: " + AxmlText.knownNames() + "\n"
                    + "replace_file(apk, path, from) - put a file the user attached (icon, image, asset) into the APK | write_file(apk, path, text) - plain text files (assets/, res/raw/)\n"
                    + "delete_file(apk, path) - path ending in / deletes a folder | changes(apk) | reset_edits(apk) | read_attachment(name, start?)\n"
                    + "extract_source(apk, package?) - exports the whole app as smali + decoded XML zip for the user (the \"source extractor\")\n"
                    + "build_apk(apk, sign?) - writes the edited APK (an XAPK bundle again when it came from one), signs it, checks it and gives it to the user. Call it once the edits are done.\n";
}
