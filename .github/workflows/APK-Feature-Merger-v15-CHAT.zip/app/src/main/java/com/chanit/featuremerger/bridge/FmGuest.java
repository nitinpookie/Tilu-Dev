package com.chanit.featuremerger.bridge;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import dalvik.system.DexClassLoader;

/** A source app that lives inside the merged APK as an asset: its own code, resources and native libs. */
final class FmGuest {
    ClassLoader cl;
    Resources res;
    ApplicationInfo ai;
    Application app;
    String apkPath;

    static FmGuest load(Context host, String asset, String appClass) throws Exception {
        File dir = new File(host.getFilesDir(), "fm");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File apk = new File(dir, new File(asset).getName());
        long want = assetLen(host, asset);
        if (!apk.exists() || (want > 0 && apk.length() != want)) {
            if (apk.exists()) {
                //noinspection ResultOfMethodCallIgnored
                apk.setWritable(true);
                //noinspection ResultOfMethodCallIgnored
                apk.delete();
            }
            copyAsset(host, asset, apk);
        }
        //noinspection ResultOfMethodCallIgnored
        apk.setReadOnly(); // Android 14 refuses writable dex containers

        FmGuest g = new FmGuest();
        g.apkPath = apk.getAbsolutePath();
        File lib = new File(dir, apk.getName() + "-lib");
        extractLibs(apk, lib);
        g.cl = new DexClassLoader(g.apkPath, host.getCodeCacheDir().getAbsolutePath(),
                lib.exists() ? lib.getAbsolutePath() : null, Context.class.getClassLoader());
        PackageManager pm = host.getPackageManager();
        PackageInfo pi = pm.getPackageArchiveInfo(g.apkPath, 0);
        if (pi == null || pi.applicationInfo == null) throw new IllegalStateException("cannot read guest apk");
        g.ai = pi.applicationInfo;
        g.ai.sourceDir = g.apkPath;
        g.ai.publicSourceDir = g.apkPath;
        g.res = pm.getResourcesForApplication(g.ai);
        if (appClass != null && appClass.length() > 0) {
            try {
                Class<?> c = g.cl.loadClass(appClass);
                Constructor<?> k = c.getDeclaredConstructor();
                k.setAccessible(true);
                Application a = (Application) k.newInstance();
                Method m = ContextWrapper.class.getDeclaredMethod("attachBaseContext", Context.class);
                m.setAccessible(true);
                m.invoke(a, new FmGuestContext(host, g));
                g.app = a;
                a.onCreate();
            } catch (Throwable t) {
                Log.w(FmBoot.TAG, "guest Application failed (continuing): " + t);
            }
        }
        return g;
    }

    private static long assetLen(Context c, String asset) {
        try {
            AssetFileDescriptor fd = c.getAssets().openFd(asset);
            long l = fd.getLength();
            fd.close();
            return l;
        } catch (Throwable t) {
            return -1;
        }
    }

    private static void copyAsset(Context c, String asset, File out) throws Exception {
        InputStream in = c.getAssets().open(asset);
        try {
            FileOutputStream o = new FileOutputStream(out);
            try {
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            } finally {
                o.close();
            }
        } finally {
            in.close();
        }
    }

    private static void extractLibs(File apk, File outDir) {
        try {
            ZipFile zf = new ZipFile(apk);
            try {
                for (String abi : Build.SUPPORTED_ABIS) {
                    String prefix = "lib/" + abi + "/";
                    boolean any = false;
                    for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                        ZipEntry e = en.nextElement();
                        if (!e.getName().startsWith(prefix) || !e.getName().endsWith(".so")) continue;
                        any = true;
                        //noinspection ResultOfMethodCallIgnored
                        outDir.mkdirs();
                        File f = new File(outDir, new File(e.getName()).getName());
                        if (f.exists() && f.length() == e.getSize()) continue;
                        InputStream in = zf.getInputStream(e);
                        try {
                            FileOutputStream o = new FileOutputStream(f);
                            try {
                                byte[] buf = new byte[1 << 16];
                                int r;
                                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                            } finally {
                                o.close();
                            }
                        } finally {
                            in.close();
                        }
                    }
                    if (any) break;
                }
            } finally {
                zf.close();
            }
        } catch (Throwable t) {
            Log.w(FmBoot.TAG, "native libs: " + t);
        }
    }
}
