package com.chanit.featuremerger.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/** Plain data classes shared by the analyzer, the merger and the UI. */
public final class Model {
    private Model() {}

    public static final int GREEN = 0, AMBER = 1, RED = 2;

    public static final class Control implements Serializable {
        private static final long serialVersionUID = 1L;
        public int viewId;
        public String idName, tag, label, layout;
        public List<String> layoutPaths = new ArrayList<>();

        public String key() { return layout + "#" + viewId; }
    }

    public static final class Feature implements Serializable {
        private static final long serialVersionUID = 1L;
        public String id;            // class descriptor of the main class
        public String label;
        public String kind;          // SERVICE | OTHER
        public String serviceName;   // dotted manifest name (SERVICE only)
        public boolean movable;
        public int level;            // GREEN / AMBER / RED
        public int classCount;
        public List<String> reasons = new ArrayList<>();
        public List<String> layouts = new ArrayList<>();
        public java.util.Map<String, ArrayList<String>> layoutFiles = new java.util.LinkedHashMap<>();
        public List<Control> controls = new ArrayList<>();
    }

    /** Something that exists in the APK but is switched off: hidden / disabled control or disabled component. */
    public static final class Hidden implements Serializable {
        private static final long serialVersionUID = 1L;
        public String kind;          // CONTROL | COMPONENT
        public String label;
        public String detail;        // human readable: where and how it is switched off
        public String how;           // gone | invisible | disabled
        public String layout;        // CONTROL
        public int viewId;           // CONTROL
        public ArrayList<String> layoutPaths = new ArrayList<>();
        public String tag, name;     // COMPONENT: manifest tag (service/activity/receiver) + dotted name

        public String key() { return kind + ":" + (kind.equals("CONTROL") ? layout + "#" + viewId : tag + ":" + name); }
    }

    public static final class Apk implements Serializable {
        private static final long serialVersionUID = 1L;
        public String path, label, pkg, versionName, appClass, iconPath, vpnClass;
        public int versionCode, minSdk, targetSdk, classCount, dexCount, obfuscation;
        public long size, stamp;
        public boolean vpn, overlayPerm, abiOk;
        public List<String> permissions = new ArrayList<>();
        public List<String> abis = new ArrayList<>();
        public List<String> notes = new ArrayList<>();
        public List<Feature> features = new ArrayList<>();
        public List<Hidden> hidden = new ArrayList<>();
    }
}
