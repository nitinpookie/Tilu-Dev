package com.chanit.featuremerger.core;

import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.BaksmaliOptions;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;
import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.reference.FieldReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.iface.reference.StringReference;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.android.tools.smali.smali.Smali;
import com.android.tools.smali.smali.SmaliOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * The "source extractor" and the smali editor: classes of an APK as smali text (what apktool / baksmali give), search in the
 * code, smali text back to dex, and writing changed classes back into the dex files. Pure Java, no native code.
 */
public final class SmaliTool {
    private SmaliTool() {}

    /** One dex file of an APK, unpacked to the work folder. */
    public static final class Dex {
        public String entry;
        public File file;
        public DexFile df;
    }

    public static String type(String name) {
        String n = name == null ? "" : name.trim();
        if (n.startsWith("L") && n.endsWith(";")) return n;
        return "L" + n.replace('.', '/') + ";";
    }

    public static String dotted(String type) {
        String t = type;
        if (t.startsWith("L") && t.endsWith(";")) t = t.substring(1, t.length() - 1);
        return t.replace('/', '.');
    }

    // ------------------------------------------------------------------ dex files of an apk
    public static List<Dex> openDex(File apk, File work) throws IOException {
        //noinspection ResultOfMethodCallIgnored
        work.mkdirs();
        List<Dex> out = new ArrayList<>();
        try (ZipFile zf = new ZipFile(apk)) {
            List<String> names = new ArrayList<>();
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                String n = en.nextElement().getName();
                if (n.matches("classes\\d*\\.dex")) names.add(n);
            }
            Collections.sort(names, (x, y) -> Integer.compare(dexNo(x), dexNo(y)));
            for (String n : names) {
                Dex d = new Dex();
                d.entry = n;
                d.file = new File(work, "dex_" + n);
                try (InputStream in = zf.getInputStream(zf.getEntry(n)); FileOutputStream o = new FileOutputStream(d.file)) {
                    byte[] buf = new byte[1 << 16];
                    int r;
                    while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                }
                d.df = DexFileFactory.loadDexFile(d.file, Opcodes.getDefault());
                out.add(d);
            }
        }
        return out;
    }

    private static int dexNo(String n) {
        String d = n.replaceAll("\\D", "");
        return d.isEmpty() ? 1 : Integer.parseInt(d);
    }

    public static void cleanup(List<Dex> dexes) {
        for (Dex d : dexes) //noinspection ResultOfMethodCallIgnored
            d.file.delete();
    }

    // ------------------------------------------------------------------ listing and reading
    /** Class descriptors whose dotted name contains filter (empty = all), at most max, plus the total in count[0]. */
    public static List<String> classes(List<Dex> dexes, String filter, int max, int[] count) {
        String f = filter == null ? "" : filter.toLowerCase();
        List<String> out = new ArrayList<>();
        int n = 0;
        for (Dex d : dexes) {
            for (ClassDef cd : d.df.getClasses()) {
                String t = cd.getType();
                if (!f.isEmpty() && !dotted(t).toLowerCase().contains(f)) continue;
                n++;
                if (out.size() < max) out.add(dotted(t) + "   [" + d.entry + "]");
            }
        }
        if (count != null && count.length > 0) count[0] = n;
        return out;
    }

    public static ClassDef find(List<Dex> dexes, String type) {
        for (Dex d : dexes) for (ClassDef cd : d.df.getClasses()) if (cd.getType().equals(type)) return cd;
        return null;
    }

    public static String smaliOf(ClassDef cd) throws IOException {
        BaksmaliOptions o = new BaksmaliOptions();
        ClassDefinition def = new ClassDefinition(o, cd);
        StringWriter sw = new StringWriter();
        // smali 3.x writes classes through a BaksmaliWriter (it wraps the plain writer); closing it flushes
        try (BaksmaliWriter w = new BaksmaliWriter(sw, null)) {
            def.writeTo(w);
        }
        return sw.toString();
    }

    /** Strings, method calls and field uses in the code that contain text. Format: class -> method : kind text */
    public static List<String> findCode(List<Dex> dexes, String text, String packagePrefix, int max, boolean[] truncated) {
        List<String> out = new ArrayList<>();
        String needle = text.toLowerCase();
        String pre = packagePrefix == null ? "" : packagePrefix.trim().toLowerCase();
        for (Dex d : dexes) {
            for (ClassDef cd : d.df.getClasses()) {
                String cn = dotted(cd.getType());
                if (!pre.isEmpty() && !cn.toLowerCase().startsWith(pre)) continue;
                if (cn.toLowerCase().contains(needle) && out.size() < max) out.add("class " + cn);
                for (Method m : cd.getMethods()) {
                    MethodImplementation impl = m.getImplementation();
                    if (impl == null) continue;
                    String where = cn + "->" + m.getName();
                    String last = null;
                    for (Instruction ins : impl.getInstructions()) {
                        if (!(ins instanceof ReferenceInstruction)) continue;
                        Reference r = ((ReferenceInstruction) ins).getReference();
                        String hit = null;
                        if (r instanceof StringReference) {
                            String s = ((StringReference) r).getString();
                            if (s.toLowerCase().contains(needle)) hit = "string \"" + shorten(s) + "\"";
                        } else if (r instanceof MethodReference) {
                            MethodReference mr = (MethodReference) r;
                            String s = dotted(mr.getDefiningClass()) + "." + mr.getName();
                            if (s.toLowerCase().contains(needle)) hit = "call " + s;
                        } else if (r instanceof FieldReference) {
                            FieldReference fr = (FieldReference) r;
                            String s = dotted(fr.getDefiningClass()) + "." + fr.getName();
                            if (s.toLowerCase().contains(needle)) hit = "field " + s;
                        }
                        if (hit != null && !hit.equals(last)) {
                            last = hit;
                            if (out.size() >= max) {
                                if (truncated != null && truncated.length > 0) truncated[0] = true;
                                return out;
                            }
                            out.add(where + " : " + hit);
                        }
                    }
                }
            }
        }
        return out;
    }

    private static String shorten(String s) {
        String t = s.replace("\n", "\\n");
        return t.length() > 120 ? t.substring(0, 120) + "..." : t;
    }

    // ------------------------------------------------------------------ smali -> class
    /** Assembles one smali class. Throws IOException with the assembler's own messages when the text is wrong. */
    public static ClassDef assemble(File work, String smaliText) throws IOException {
        //noinspection ResultOfMethodCallIgnored
        work.mkdirs();
        File in = new File(work, "edit_in.smali");
        File outDex = new File(work, "edit_out.dex");
        try (FileOutputStream o = new FileOutputStream(in)) {
            o.write(smaliText.getBytes("UTF-8"));
        }
        //noinspection ResultOfMethodCallIgnored
        outDex.delete();
        SmaliOptions so = new SmaliOptions();
        so.apiLevel = 29;
        so.outputDexFile = outDex.getPath();
        so.jobs = 1;
        PrintStream oldErr = System.err;
        ByteArrayOutputStream cap = new ByteArrayOutputStream();
        boolean ok;
        try {
            System.setErr(new PrintStream(cap, true, "UTF-8"));
            ok = Smali.assemble(so, Collections.singletonList(in.getPath()));
        } catch (RuntimeException e) {
            throw new IOException("smali: " + e);
        } finally {
            System.setErr(oldErr);
            //noinspection ResultOfMethodCallIgnored
            in.delete();
        }
        String msg = cap.toString("UTF-8").replace(in.getPath(), "class.smali").trim();
        if (!ok || !outDex.exists()) {
            throw new IOException("smali could not assemble this class:\n" + (msg.isEmpty() ? "(no message)" : msg.length() > 1500 ? msg.substring(0, 1500) : msg));
        }
        try {
            DexFile df = DexFileFactory.loadDexFile(outDex, Opcodes.getDefault());
            for (ClassDef cd : df.getClasses()) return cd;
            throw new IOException("the smali text has no .class");
        } finally {
            //noinspection ResultOfMethodCallIgnored
            outDex.delete();
        }
    }

    private static final Pattern METHOD = Pattern.compile("(?m)^\\.method\\b([^\\n]*)$");

    /**
     * Replaces the body of a method so that it only returns a constant (or nothing). value: void | true | false | null | 0 | 1 | a number.
     * Returns the new smali text, or throws IOException when the method is not found / has no body.
     */
    public static String stubMethod(String smali, String methodName, String value) throws IOException {
        Matcher m = METHOD.matcher(smali);
        int done = 0;
        StringBuilder out = new StringBuilder();
        int pos = 0;
        while (m.find()) {
            String head = m.group(1).trim();
            int paren = head.indexOf('(');
            if (paren < 0) continue;
            int sp = head.lastIndexOf(' ', paren);
            String name = head.substring(sp + 1, paren);
            if (!name.equals(methodName)) continue;
            if (head.contains(" abstract ") || head.startsWith("abstract ") || head.contains(" native ") || head.startsWith("native ")) continue;
            int end = smali.indexOf("\n.end method", m.end());
            if (end < 0) throw new IOException("no .end method for " + methodName);
            String ret = head.substring(head.indexOf(')', paren) + 1).trim();
            String body = stubBody(ret, value);
            out.append(smali, pos, m.end()).append('\n').append(body);
            pos = end;
            done++;
        }
        if (done == 0) throw new IOException("method \"" + methodName + "\" with a body was not found in this class");
        out.append(smali.substring(pos));
        return out.toString();
    }

    private static String stubBody(String ret, String value) throws IOException {
        String v = value == null ? "" : value.trim().toLowerCase();
        char c = ret.isEmpty() ? 'V' : ret.charAt(0);
        if (c == 'V') return "    .locals 0\n    return-void";
        if (c == 'L' || c == '[') {
            if (!v.isEmpty() && !v.equals("null") && !v.equals("0")) throw new IOException("an object-returning method can only be stubbed with null");
            return "    .locals 1\n    const/4 v0, 0x0\n    return-object v0";
        }
        long n;
        if (v.equals("true")) n = 1;
        else if (v.equals("false") || v.isEmpty() || v.equals("null")) n = 0;
        else {
            try {
                n = v.startsWith("0x") ? Long.parseLong(v.substring(2), 16) : Long.parseLong(v);
            } catch (NumberFormatException e) {
                throw new IOException("value must be true, false, null or a number");
            }
        }
        if (c == 'J' || c == 'D') return "    .locals 2\n    const-wide v0, 0x" + Long.toHexString(n) + "L\n    return-wide v0";
        if (c == 'F') return "    .locals 1\n    const v0, 0x" + Integer.toHexString((int) n) + "\n    return v0";
        return "    .locals 1\n    const v0, 0x" + Integer.toHexString((int) n) + "\n    return v0";
    }

    // ------------------------------------------------------------------ write classes back
    /**
     * Returns the new bytes of every dex file that changed: classes in repl replace the class with the same type (a type that
     * exists nowhere is added to the first dex), types in remove are dropped.
     */
    public static Map<String, byte[]> rewrite(List<Dex> dexes, Map<String, ClassDef> repl, Set<String> remove, File work) throws IOException {
        Map<String, byte[]> out = new LinkedHashMap<>();
        java.util.HashSet<String> placed = new java.util.HashSet<>();
        for (int i = 0; i < dexes.size(); i++) {
            Dex d = dexes.get(i);
            boolean touched = false;
            for (ClassDef cd : d.df.getClasses()) {
                if (repl.containsKey(cd.getType()) || remove.contains(cd.getType())) {
                    touched = true;
                    break;
                }
            }
            boolean addHere = i == 0;
            if (!touched && !addHere) continue;
            DexPool pool = new DexPool(d.df.getOpcodes());
            boolean changed = touched;
            for (ClassDef cd : d.df.getClasses()) {
                String t = cd.getType();
                if (remove.contains(t)) continue;
                ClassDef r = repl.get(t);
                if (r != null) {
                    pool.internClass(r);
                    placed.add(t);
                } else {
                    pool.internClass(cd);
                }
            }
            if (addHere) {
                // classes that were not in any dex yet
                for (Map.Entry<String, ClassDef> e : repl.entrySet()) {
                    if (placed.contains(e.getKey()) || find(dexes, e.getKey()) != null) continue;
                    pool.internClass(e.getValue());
                    placed.add(e.getKey());
                    changed = true;
                }
            }
            if (!changed) continue;
            File tmp = new File(work, "rewrite_" + d.entry);
            pool.writeTo(new FileDataStore(tmp));
            byte[] data = ApkZip.readFile(tmp);
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            out.put(d.entry, data);
        }
        return out;
    }
}
