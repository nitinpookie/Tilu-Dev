package com.chanit.featuremerger;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chanit.featuremerger.core.ApkAnalyzer;
import com.chanit.featuremerger.core.Model;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * The "Add app" sheet: three ways to pick an APK.
 *  Installed: every app on the phone (its base.apk is copied), VPN apps are marked and listed first for the VPN slot.
 *  Files:     every .apk found in Download and other folders (needs the file-access permission, asked right here).
 *  Browse:    the system file picker (needs no permission at all).
 */
final class AddAppSheet {
    private static final int TAB_INSTALLED = 0, TAB_FILES = 1, TAB_BROWSE = 2;
    private static final String BIND_VPN = "android.permission.BIND_VPN_SERVICE";
    private static final Set<String> SKIP_DIRS = new HashSet<>(Arrays.asList(
            "DCIM", "Pictures", "Movies", "Music", "Podcasts", "Ringtones", "Alarms", "Notifications", "Audiobooks",
            "Recordings", "cache", "thumbnails", "Thumbnails"));

    static final class Item {
        String title, sub, pkg, path;
        long size, mtime;
        boolean vpn, system;
        Drawable icon;

        String key() { return pkg != null ? "p:" + pkg : "f:" + path; }
    }

    private final MainActivity act;
    private final int role;
    private final BottomSheetDialog dlg;
    private final View boxMsg, searchRow;
    private final TabLayout tabs;
    private final RecyclerView rv;
    private final TextView tvMsg;
    private final MaterialButton btnMsg;
    private final LinearProgressIndicator prog;
    private final TextInputEditText etSearch;
    private final Chip chipSystem;
    private final PickAdapter adapter = new PickAdapter();
    private final List<Item> installed = new ArrayList<>();
    private final List<Item> files = new ArrayList<>();
    private final Set<String> added = new HashSet<>();
    private int tab = -1;
    private boolean installedLoaded, installedLoading, filesLoaded, filesLoading;
    private volatile boolean closed;

    AddAppSheet(MainActivity a, int role) {
        act = a;
        this.role = role;
        dlg = new BottomSheetDialog(a);
        View root = LayoutInflater.from(a).inflate(R.layout.sheet_add_app, null, false);
        boxMsg = root.findViewById(R.id.boxMsg);
        searchRow = root.findViewById(R.id.searchRow);
        tabs = root.findViewById(R.id.tabs);
        rv = root.findViewById(R.id.rvPick);
        tvMsg = root.findViewById(R.id.tvMsg);
        btnMsg = root.findViewById(R.id.btnMsg);
        prog = root.findViewById(R.id.prog);
        etSearch = root.findViewById(R.id.etSearch);
        chipSystem = root.findViewById(R.id.chipSystem);

        TextView title = root.findViewById(R.id.tvSheetTitle);
        TextView sub = root.findViewById(R.id.tvSheetSub);
        if (role == MainActivity.ROLE_VPN) {
            title.setText("Add VPN app");
            sub.setText("Pick the VPN app. Apps that contain a VPN are marked VPN and listed first.");
        } else if (role == MainActivity.ROLE_GAME) {
            title.setText("Add game / app");
            sub.setText("Pick the game or app that the VPN should also support.");
        } else {
            title.setText("Add APK");
            sub.setText("Pick one or more apps. You can add several, then close this sheet.");
        }

        rv.setLayoutManager(new LinearLayoutManager(a));
        rv.setAdapter(adapter);

        tabs.addTab(tabs.newTab().setText("Installed"));
        tabs.addTab(tabs.newTab().setText("Files"));
        tabs.addTab(tabs.newTab().setText("Browse"));
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab t) { select(t.getPosition()); }
            @Override public void onTabUnselected(TabLayout.Tab t) { }
            @Override public void onTabReselected(TabLayout.Tab t) { }
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int af) { }
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { applyFilter(); }
        });
        chipSystem.setOnCheckedChangeListener((b, c) -> applyFilter());

        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        dlg.setContentView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (dm.heightPixels * 0.82f)));
        dlg.setOnDismissListener(d -> closed = true);
        try {
            if (dlg.getWindow() != null) dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        } catch (Throwable ignored) { }
    }

    void show() {
        dlg.show();
        try {
            BottomSheetBehavior<FrameLayout> b = dlg.getBehavior();
            b.setSkipCollapsed(true);
            b.setState(BottomSheetBehavior.STATE_EXPANDED);
        } catch (Throwable ignored) { }
        select(TAB_INSTALLED);
    }

    void dismiss() {
        closed = true;
        try { dlg.dismiss(); } catch (Throwable ignored) { }
    }

    /** Called after the user came back from the permission screen. */
    void onFileAccessChanged() {
        if (closed) return;
        if (tab == TAB_FILES) select(TAB_FILES);
    }

    // ------------------------------------------------------------------ tabs
    private void select(int t) {
        tab = t;
        chipSystem.setVisibility(t == TAB_INSTALLED ? View.VISIBLE : View.GONE);
        searchRow.setVisibility(t == TAB_BROWSE ? View.GONE : View.VISIBLE);
        boxMsg.setVisibility(View.GONE);
        rv.setVisibility(View.VISIBLE);
        prog.setVisibility(isLoading() ? View.VISIBLE : View.GONE);
        if (t == TAB_INSTALLED) {
            loadInstalled();
            applyFilter();
        } else if (t == TAB_FILES) {
            if (!act.hasFileAccess()) {
                adapter.set(new ArrayList<>());
                showMessage("To list the APK files in Download and your other folders, this app needs permission to see files.\n\nOr use the Browse tab, which needs no permission.",
                        "Allow file access", () -> act.requestFileAccess());
            } else {
                loadFiles();
                applyFilter();
            }
        } else {
            adapter.set(new ArrayList<>());
            showMessage("Pick any APK from any folder with the phone's own file picker. No permission needed.",
                    "Open file picker", () -> {
                        dismiss();
                        act.launchBrowse(role);
                    });
        }
    }

    private boolean isLoading() {
        return (tab == TAB_INSTALLED && installedLoading) || (tab == TAB_FILES && filesLoading);
    }

    private void showMessage(String text, String button, Runnable onClick) {
        rv.setVisibility(View.GONE);
        boxMsg.setVisibility(View.VISIBLE);
        tvMsg.setText(text);
        if (button == null) {
            btnMsg.setVisibility(View.GONE);
        } else {
            btnMsg.setVisibility(View.VISIBLE);
            btnMsg.setText(button);
            btnMsg.setOnClickListener(v -> onClick.run());
        }
    }

    private void applyFilter() {
        if (tab != TAB_INSTALLED && tab != TAB_FILES) return;
        List<Item> src = tab == TAB_INSTALLED ? installed : files;
        String q = etSearch.getText() == null ? "" : etSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean sys = chipSystem.isChecked();
        List<Item> out = new ArrayList<>();
        for (Item it : src) {
            if (tab == TAB_INSTALLED && it.system && !sys && !it.vpn && q.isEmpty()) continue;
            if (!q.isEmpty()) {
                boolean hit = it.title.toLowerCase(Locale.ROOT).contains(q)
                        || (it.pkg != null && it.pkg.toLowerCase(Locale.ROOT).contains(q))
                        || (it.path != null && it.path.toLowerCase(Locale.ROOT).contains(q));
                if (!hit) continue;
            }
            out.add(it);
        }
        adapter.set(out);
        if (out.isEmpty() && !isLoading()) {
            if (tab == TAB_INSTALLED) showMessage("No apps to show here. Switch on \"System\" to include system apps, or use the Files / Browse tab.", null, null);
            else showMessage("No .apk files found in Download or the other folders. Use the Browse tab to pick a file from anywhere.", "Open file picker", () -> {
                dismiss();
                act.launchBrowse(role);
            });
        } else {
            boxMsg.setVisibility(View.GONE);
            rv.setVisibility(View.VISIBLE);
        }
    }

    // ------------------------------------------------------------------ installed apps
    private void sortInstalled(List<Item> l) {
        Collections.sort(l, (a, b) -> {
            if (role == MainActivity.ROLE_VPN && a.vpn != b.vpn) return a.vpn ? -1 : 1;
            if (a.system != b.system) return a.system ? 1 : -1;
            return a.title.compareToIgnoreCase(b.title);
        });
    }

    private void loadInstalled() {
        if (installedLoaded || installedLoading) return;
        installedLoading = true;
        prog.setVisibility(View.VISIBLE);
        new Thread(() -> {
            final List<Item> out = new ArrayList<>();
            String err = null;
            try {
                PackageManager pm = act.getPackageManager();
                List<ApplicationInfo> list = pm.getInstalledApplications(0);
                if (list != null) {
                    for (ApplicationInfo ai : list) {
                        if (ai == null || ai.packageName == null || ai.sourceDir == null) continue;
                        if (ai.packageName.equals(act.getPackageName())) continue;
                        Item it = new Item();
                        it.pkg = ai.packageName;
                        it.path = ai.sourceDir;
                        CharSequence l = null;
                        try { l = pm.getApplicationLabel(ai); } catch (Throwable ignored) { }
                        it.title = l != null ? l.toString() : ai.packageName;
                        it.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                        it.size = new File(ai.sourceDir).length();
                        it.sub = ai.packageName + "  |  " + mb(it.size);
                        out.add(it);
                    }
                }
            } catch (Throwable t) {
                err = ApkAnalyzer.brief(t);
            }
            sortInstalled(out);
            final List<Item> first = new ArrayList<>(out);
            final String fe = err;
            act.ui.post(() -> {
                if (closed) return;
                if (fe != null) act.log("Installed apps list problem: " + fe);
                installed.clear();
                installed.addAll(first);
                installedLoaded = true;
                if (first.isEmpty()) installedLoading = false;
                if (tab == TAB_INSTALLED) {
                    prog.setVisibility(first.isEmpty() ? View.GONE : View.VISIBLE);
                    applyFilter();
                }
            });
            if (out.isEmpty()) return;

            // second pass: mark the apps that contain a VPN service
            try {
                PackageManager pm = act.getPackageManager();
                for (Item it : out) {
                    if (closed) return;
                    try {
                        PackageInfo pi = pm.getPackageInfo(it.pkg, PackageManager.GET_SERVICES);
                        if (pi.services != null) {
                            for (ServiceInfo si : pi.services) {
                                if (si != null && BIND_VPN.equals(si.permission)) {
                                    it.vpn = true;
                                    break;
                                }
                            }
                        }
                    } catch (Throwable ignored) { }
                }
            } catch (Throwable ignored) { }
            sortInstalled(out);
            final List<Item> second = new ArrayList<>(out);
            act.ui.post(() -> {
                installedLoading = false;
                if (closed) return;
                installed.clear();
                installed.addAll(second);
                if (tab == TAB_INSTALLED) {
                    prog.setVisibility(View.GONE);
                    applyFilter();
                }
            });
        }).start();
    }

    // ------------------------------------------------------------------ files
    private void loadFiles() {
        if (filesLoaded || filesLoading) return;
        filesLoading = true;
        prog.setVisibility(View.VISIBLE);
        new Thread(() -> {
            final List<Item> out = new ArrayList<>();
            try {
                Set<String> seen = new HashSet<>();
                int[] budget = {20000};
                List<File> roots = new ArrayList<>();
                File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (dl != null) roots.add(dl);
                File ext = Environment.getExternalStorageDirectory();
                if (ext != null) roots.add(ext);
                File[] vols = new File("/storage").listFiles();   // may be null: then there is just no SD card to look at
                if (vols != null) {
                    for (File v : vols) {
                        String n = v.getName();
                        if (!n.equals("emulated") && !n.equals("self") && v.canRead()) roots.add(v);
                    }
                }
                for (File r : roots) {
                    if (closed) return;
                    walk(r, 0, out, seen, budget);
                }
            } catch (Throwable t) {
                act.log("File scan problem: " + ApkAnalyzer.brief(t));
            }
            Collections.sort(out, (a, b) -> Long.compare(b.mtime, a.mtime));
            act.ui.post(() -> {
                filesLoading = false;
                if (closed) return;
                files.clear();
                files.addAll(out);
                filesLoaded = true;
                if (tab == TAB_FILES) {
                    prog.setVisibility(View.GONE);
                    applyFilter();
                }
            });
        }).start();
    }

    private void walk(File dir, int depth, List<Item> out, Set<String> seen, int[] budget) {
        if (depth > 5 || budget[0] <= 0 || closed) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;   // folder cannot be read: skip it instead of crashing
        for (File f : kids) {
            if (--budget[0] <= 0 || closed) return;
            String n = f.getName();
            if (f.isDirectory()) {
                if (n.startsWith(".") || SKIP_DIRS.contains(n) || (depth == 0 && n.equals("Android"))) continue;
                walk(f, depth + 1, out, seen, budget);
            } else if (n.toLowerCase(Locale.ROOT).endsWith(".apk")) {
                String key;
                try { key = f.getCanonicalPath(); } catch (Exception e) { key = f.getAbsolutePath(); }
                if (!seen.add(key)) continue;
                Item it = new Item();
                it.path = f.getAbsolutePath();
                it.title = n;
                it.size = f.length();
                it.mtime = f.lastModified();
                String parent = f.getParent() == null ? "" : f.getParent().replace("/storage/emulated/0", "Internal storage");
                it.sub = parent + "  |  " + mb(it.size);
                out.add(it);
            }
        }
    }

    private static String mb(long size) { return String.format(Locale.US, "%.1f MB", size / 1048576.0); }

    // ------------------------------------------------------------------ picking
    private void pick(Item it) {
        if (it.pkg != null) {
            Model.Apk existing = act.findAdded(it.pkg);
            if (existing != null) {
                Toast.makeText(act, it.title + " is already in your list", Toast.LENGTH_SHORT).show();
                if (role != MainActivity.ROLE_ANY && act.vpnCtl != null) act.vpnCtl.assign(role, existing);
                added.add(it.key());
                if (role != MainActivity.ROLE_ANY) dismiss(); else adapter.notifyDataSetChanged();
                return;
            }
            act.importPath(it.path, it.pkg + ".apk", role);
        } else {
            act.importPath(it.path, it.title, role);
        }
        added.add(it.key());
        Toast.makeText(act, "Adding " + it.title + " ...", Toast.LENGTH_SHORT).show();
        if (role != MainActivity.ROLE_ANY) dismiss(); else adapter.notifyDataSetChanged();
    }

    private static final class VH extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView name, sub, tag;

        VH(View v) {
            super(v);
            icon = v.findViewById(R.id.ivPick);
            name = v.findViewById(R.id.tvPickName);
            sub = v.findViewById(R.id.tvPickSub);
            tag = v.findViewById(R.id.tvPickTag);
        }
    }

    private final class PickAdapter extends RecyclerView.Adapter<VH> {
        private final List<Item> items = new ArrayList<>();

        void set(List<Item> l) {
            items.clear();
            items.addAll(l);
            notifyDataSetChanged();
        }

        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
            return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.row_pick, p, false));
        }

        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            final Item it = items.get(pos);
            h.name.setText(it.title);
            h.sub.setText(it.sub == null ? "" : it.sub);
            if (it.pkg != null && it.icon == null) {
                try { it.icon = act.getPackageManager().getApplicationIcon(it.pkg); } catch (Throwable ignored) { }
            }
            if (it.icon != null) h.icon.setImageDrawable(it.icon);
            else h.icon.setImageResource(it.pkg != null ? R.drawable.ic_launcher : R.drawable.ic_apps);
            boolean isAdded = added.contains(it.key()) || (it.pkg != null && act.findAdded(it.pkg) != null);
            h.tag.setText(isAdded ? "Added" : it.vpn ? "VPN" : "");
            h.itemView.setOnClickListener(v -> pick(it));
        }

        @Override public int getItemCount() { return items.size(); }
    }
}
