package com.chanit.featuremerger.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ready-made improvements ("recipes") for each VPN feature, and a plain keyword reader for the user's own words.
 * No AI and no internet inside the app: the recipes below are the researched best practice:
 *  - DNS: if the VPN sets none, Android uses the DNS of the normal network (can leak to the provider); a fast public
 *    resolver set inside the tunnel fixes that.
 *  - MTU: 1420 is WireGuard's classic default, mobile networks and CGNAT often need ~1380-1400 (Mullvad ships 1380),
 *    1280 is the IPv6 minimum and the fallback when connections stall.
 *  - IPv6: an IPv4-only tunnel lets IPv6 traffic bypass it, so IPv6 is sent into the tunnel as well.
 *  - Always-on: Android supports it unless the VPN service opts out; the kill switch is Android's
 *    "Block connections without VPN".
 */
public final class Instruct {
    private Instruct() {}

    public static final String[][] DNS_PRESETS = {
            {"Cloudflare (fast, private)", "1.1.1.1,1.0.0.1"},
            {"Google", "8.8.8.8,8.8.4.4"},
            {"Quad9 (blocks malware)", "9.9.9.9,149.112.112.112"},
            {"AdGuard (blocks ads)", "94.140.14.14,94.140.15.15"}};

    public static final String[][] MTU_PRESETS = {
            {"Fast (1420)", "1420"},
            {"Mobile safe (1380)", "1380"},
            {"Max compatibility (1280)", "1280"}};

    public static final class Recipe {
        public final String label, hint;
        public final List<VpnEnhancer.Op> ops = new ArrayList<>();

        Recipe(String label, String hint) {
            this.label = label;
            this.hint = hint;
        }
    }

    public static final class Out {
        public final List<VpnEnhancer.Op> ops = new ArrayList<>();
        public final List<String> understood = new ArrayList<>();
        public String leftover = "";
    }

    // ------------------------------------------------------------------ recipes
    public static List<Recipe> recipes(VpnFeatures.Feat f) {
        List<Recipe> out = new ArrayList<>();
        switch (f.kind) {
            case VpnFeatures.E_DNS:
                for (String[] d : DNS_PRESETS) out.add(one("DNS: " + d[0], "", dns(d[0], d[1])));
                break;
            case VpnFeatures.E_MTU:
                for (String[] m : MTU_PRESETS) out.add(one("MTU: " + m[0], "", mtu(m[0], m[1])));
                break;
            case VpnFeatures.E_ROUTE:
                out.add(matchFix());
                break;
            case VpnFeatures.E_V6:
                out.add(one("Block IPv6 leak", "", v6()));
                break;
            case VpnFeatures.E_MET:
                out.add(one("Treat VPN as unmetered", "", met()));
                break;
            case VpnFeatures.E_AON:
                out.add(one("Turn always-on support ON", "", aon()));
                break;
            case VpnFeatures.E_START: {
                out.add(matchFix());
                Recipe r = new Recipe("Balanced bundle (recommended)", "");
                r.ops.add(dns(DNS_PRESETS[0][0], DNS_PRESETS[0][1]));
                r.ops.add(mtu(MTU_PRESETS[1][0], MTU_PRESETS[1][1]));
                r.ops.add(v6());
                r.ops.add(met());
                out.add(r);
                break;
            }
            case VpnFeatures.C_CTL:
                if (f.checkable) {
                    out.add(one("Switch ON by default", "", ctl(f, VpnEnhancer.CHECK_ON, "ON by default")));
                    out.add(one("Switch OFF by default", "", ctl(f, VpnEnhancer.CHECK_OFF, "OFF by default")));
                }
                out.add(one("Hide it", "", ctl(f, VpnEnhancer.HIDE, "hidden")));
                out.add(one("Show / enable it", "", ctl(f, VpnEnhancer.SHOW, "shown and enabled")));
                break;
            default:
                break;
        }
        return out;
    }

    /**
     * An OLDER game version (for example 2022) reaches the lobby but not the match while the current version works: the old
     * client uses other match servers and UDP ports than the ones the VPN routes. Send everything of the game through the VPN
     * and use a packet size that survives UDP on mobile networks.
     */
    public static Recipe matchFix() {
        Recipe r = new Recipe("Fix: old game version, lobby works but no match", "route everything of the game + MTU 1380");
        r.ops.add(routeOp("0.0.0.0/0"));
        r.ops.add(mtu("", "1380"));
        return r;
    }

    private static Recipe one(String label, String hint, VpnEnhancer.Op op) {
        Recipe r = new Recipe(label, hint);
        r.ops.add(op);
        return r;
    }

    static VpnEnhancer.Op dns(String name, String ips) { return new VpnEnhancer.Op(VpnEnhancer.DNS, ips, "DNS \u2192 " + name + " (" + ips + ")"); }

    static VpnEnhancer.Op mtu(String name, String v) { return new VpnEnhancer.Op(VpnEnhancer.MTU, v, "MTU \u2192 " + v); }

    static VpnEnhancer.Op v6() { return new VpnEnhancer.Op(VpnEnhancer.V6, "1", "Block IPv6 leak (IPv6 goes into the tunnel)"); }

    static VpnEnhancer.Op met() { return new VpnEnhancer.Op(VpnEnhancer.MET, "0", "Treat the VPN as unmetered"); }

    public static VpnEnhancer.Op appsOp(String csv) { return new VpnEnhancer.Op(VpnEnhancer.APPS, csv, "Games \u2192 " + csv + " (allowed whenever the VPN allows an app; same game again = rewritten)"); }

    public static VpnEnhancer.Op routeOp(String csv) { return new VpnEnhancer.Op(VpnEnhancer.ROUTE, csv, "Server routes \u2192 " + csv + " (sent into the tunnel)"); }

    private static final Pattern PKG_TOKEN = Pattern.compile("\\b[a-z][a-z0-9_]*(?:\\.[a-z0-9_]+)+\\b");
    private static final Pattern CIDR_TOKEN = Pattern.compile("\\b(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)(?:/(?:3[0-2]|[12]?\\d))?\\b");

    /** Android package names found in the text, comma separated (max 6), or "" */
    public static String cleanPackages(String raw) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        Matcher m = PKG_TOKEN.matcher(raw == null ? "" : raw.toLowerCase(Locale.ROOT));
        java.util.Set<String> seen = new java.util.LinkedHashSet<>();
        while (m.find() && n < 6) {
            String t = m.group();
            if (IP.matcher(t).matches() || !seen.add(t)) continue;
            sb.append(sb.length() > 0 ? "," : "").append(t);
            n++;
        }
        return sb.toString();
    }

    /** IPv4 addresses (optionally with /prefix) found in the text, comma separated (max 8), or "" */
    public static String cleanCidrs(String raw) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        Matcher m = CIDR_TOKEN.matcher(raw == null ? "" : raw);
        java.util.Set<String> seen = new java.util.LinkedHashSet<>();
        while (m.find() && n < 8) {
            String t = m.group();
            if (!seen.add(t)) continue;
            sb.append(sb.length() > 0 ? "," : "").append(t);
            n++;
        }
        return sb.toString();
    }

    static VpnEnhancer.Op aon() { return new VpnEnhancer.Op(VpnEnhancer.AON, "1", "Always-on / kill switch support ON"); }

    static VpnEnhancer.Op ctl(VpnFeatures.Feat f, String kind, String what) {
        VpnEnhancer.Op o = new VpnEnhancer.Op(kind, "", "\"" + f.title + "\" (" + f.group + ") \u2192 " + what);
        o.ctl = f;
        return o;
    }

    // ------------------------------------------------------------------ the user's own words (keywords only)
    private static final Pattern IP = Pattern.compile("\\b(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\b");
    private static final Pattern NUM = Pattern.compile("\\b(1[2-5]\\d\\d)\\b");

    public static Out parse(VpnFeatures.Feat f, String raw) {
        Out o = new Out();
        String t = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        if (t.isEmpty()) return o;
        if (VpnFeatures.C_CTL.equals(f.kind)) {
            controls(f, t, o);
        } else {
            engine(f, t, o);
        }
        if (o.ops.isEmpty()) o.leftover = raw.trim();
        return o;
    }

    private static boolean any(String t, String... w) {
        for (String s : w) if (t.contains(s)) return true;
        return false;
    }

    private static void engine(VpnFeatures.Feat f, String t, Out o) {
        // private server IPs -> routes (not DNS)
        boolean routeCtx = VpnFeatures.E_ROUTE.equals(f.kind) || any(t, "route", "private server", "server ip", "game server");
        String cidrs = routeCtx ? cleanCidrs(t) : "";
        if (!cidrs.isEmpty()) {
            o.ops.add(routeOp(cidrs));
            o.understood.add("Server routes: " + cidrs);
        }
        // games (package names)
        if (VpnFeatures.E_APPS.equals(f.kind) || any(t, "game", "package", "apk")) {
            String pk = cleanPackages(t);
            if (!pk.isEmpty()) {
                o.ops.add(appsOp(pk));
                o.understood.add("Games: " + pk);
            }
        }
        // "lobby works but the match does not start"
        if (any(t, "match", "lobby") && !any(t, "dns")) {
            Recipe mf = matchFix();
            o.ops.addAll(mf.ops);
            o.understood.add("Match fix: " + mf.hint);
        }
        // DNS
        List<String> ips = new ArrayList<>();
        Matcher m = IP.matcher(t);
        while (m.find() && ips.size() < 4) ips.add(m.group());
        boolean dnsWord = t.contains("dns") || any(t, "cloudflare", "quad9", "adguard", "google");
        if (cidrs.isEmpty() && (dnsWord || !ips.isEmpty()) && !routeCtx) {
            if (!ips.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (String s : ips) sb.append(sb.length() > 0 ? "," : "").append(s);
                o.ops.add(dns("your servers", sb.toString()));
                o.understood.add("DNS: " + sb);
            } else {
                String[] p = DNS_PRESETS[0];
                if (any(t, "google", "8.8.8.8")) p = DNS_PRESETS[1];
                else if (any(t, "quad9", "malware", "secure")) p = DNS_PRESETS[2];
                else if (any(t, "adguard", "ads", "ad block", "adblock", "vigyapan")) p = DNS_PRESETS[3];
                o.ops.add(dns(p[0], p[1]));
                o.understood.add("DNS: " + p[0]);
            }
        }
        // MTU
        if (t.contains("mtu") || any(t, "packet size", "fragment", "speed", "fast", "tez", "stable", "drop")) {
            String v = null;
            Matcher n = NUM.matcher(t);
            if (n.find()) v = n.group(1);
            if (v == null) {
                if (any(t, "compat", "1280")) v = "1280";
                else if (any(t, "fast", "speed", "tez", "boost")) v = "1420";
                else v = "1380";
            }
            o.ops.add(mtu("", v));
            o.understood.add("MTU: " + v);
        }
        if (any(t, "ipv6", " v6", "leak") && !(t.contains("dns leak") && !t.contains("ipv6"))) {
            o.ops.add(v6());
            o.understood.add("IPv6 leak block");
        }
        if (any(t, "metered", "data saver", "download limit")) {
            o.ops.add(met());
            o.understood.add("Unmetered VPN");
        }
        if (any(t, "kill", "always", "lockdown", "reconnect", "auto connect", "on boot")) {
            o.ops.add(aon());
            o.understood.add("Always-on / kill switch support");
        }
    }

    private static void controls(VpnFeatures.Feat f, String t, Out o) {
        t = " " + t + " ";
        if (any(t, "hide", "chhupa", "chupa", "hata", "remove", "gayab")) {
            o.ops.add(ctl(f, VpnEnhancer.HIDE, "hidden"));
            o.understood.add("hide");
        } else if (any(t, "show", "unhide", "dikha", "visible")) {
            o.ops.add(ctl(f, VpnEnhancer.SHOW, "shown and enabled"));
            o.understood.add("show / enable");
        } else if (f.checkable && any(t, "off", "band", "disable", "unchecked")) {
            o.ops.add(ctl(f, VpnEnhancer.CHECK_OFF, "OFF by default"));
            o.understood.add("OFF by default");
        } else if (f.checkable && any(t, " on", "on ", "chalu", "enable", "checked", "default")) {
            o.ops.add(ctl(f, VpnEnhancer.CHECK_ON, "ON by default"));
            o.understood.add("ON by default");
        }
    }
}
