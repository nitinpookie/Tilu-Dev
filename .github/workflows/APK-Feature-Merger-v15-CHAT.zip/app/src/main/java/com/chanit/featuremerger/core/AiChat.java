package com.chanit.featuremerger.core;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Multi-turn chat with the provider the user set up in "AI setup" (same keys, same model discovery as the rest of the app),
 * with images (screenshots) as input. One call = the whole conversation so far; the caller keeps the history.
 */
public final class AiChat {
    private AiChat() {}

    public static final class Img {
        public final String mime, b64;

        public Img(String mime, String b64) {
            this.mime = mime;
            this.b64 = b64;
        }
    }

    public static final class Msg {
        public String role, text;
        public List<Img> images = new ArrayList<>();

        public Msg(String role, String text) {
            this.role = role;
            this.text = text == null ? "" : text;
        }
    }

    public static final class Reply {
        public String text = "", model = "";
        public boolean visionDropped;
    }

    public interface Note {
        void say(String s);
    }

    private static final class Limited extends Exception {
        Limited(String m) { super(m); }
    }

    /** Checks key and daily cap once per user message (the cap counts messages, not the steps inside one). */
    public static void startTurn(Context c) throws AiHelper.AiException {
        AiHelper.Config cfg = AiHelper.load(c);
        AiHelper.Prov pv = AiHelper.prov(cfg.provider);
        if (!cfg.ready()) throw new AiHelper.AiException("AI key abhi set nahi hai. Enhance screen > \"AI setup\" me " + pv.label + " ki key paste karo (chat ke menu me bhi \"AI setup\" hai).");
        int used = AiHelper.usedToday(c);
        if (used >= cfg.cap) throw new AiHelper.AiException("Aaj ki AI limit puri ho gayi (" + used + "/" + cfg.cap + "). Kal try karo, ya AI setup me limit badhao.");
        AiHelper.bump(c);
    }

    public static Reply complete(Context c, String system, List<Msg> history, Note note) throws AiHelper.AiException {
        AiHelper.Config cfg = AiHelper.load(c);
        AiHelper.Prov pv = AiHelper.prov(cfg.provider);
        if (!cfg.ready()) throw new AiHelper.AiException("AI key abhi set nahi hai. \"AI setup\" me " + pv.label + " ki key paste karo.");
        List<Msg> msgs = normalize(history);
        if (msgs.isEmpty()) throw new AiHelper.AiException("Khali message.");
        int[] waits = {8, 16, 30};
        for (int attempt = 0; ; attempt++) {
            try {
                if (AiHelper.CLAUDE.equals(cfg.provider)) return claude(cfg, system, msgs);
                if (AiHelper.GEMINI.equals(cfg.provider)) return gemini(cfg, system, msgs);
                return compat(cfg, pv, system, msgs);
            } catch (Limited l) {
                if (attempt >= waits.length) throw new AiHelper.AiException(l.getMessage());
                if (note != null) note.say("Provider ki limit lagi, " + waits[attempt] + " sec ruk kar dobara try karunga");
                try {
                    Thread.sleep(waits[attempt] * 1000L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new AiHelper.AiException("Roka gaya.");
                }
            }
        }
    }

    /** Providers want user / assistant strictly alternating and the first message from the user. */
    private static List<Msg> normalize(List<Msg> in) {
        List<Msg> out = new ArrayList<>();
        for (Msg m : in) {
            if (m.text.trim().isEmpty() && m.images.isEmpty()) continue;
            Msg last = out.isEmpty() ? null : out.get(out.size() - 1);
            if (last != null && last.role.equals(m.role)) {
                last.text = last.text + "\n\n" + m.text;
                last.images.addAll(m.images);
            } else {
                Msg c = new Msg(m.role, m.text);
                c.images.addAll(m.images);
                out.add(c);
            }
        }
        while (!out.isEmpty() && !"user".equals(out.get(0).role)) out.remove(0);
        return out;
    }

    private static boolean hasImages(List<Msg> msgs) {
        for (Msg m : msgs) if (!m.images.isEmpty()) return true;
        return false;
    }

    // ------------------------------------------------------------------ Gemini
    private static Reply gemini(AiHelper.Config cfg, String system, List<Msg> msgs) throws AiHelper.AiException, Limited {
        List<String> models = AiHelper.geminiCandidates(cfg);
        boolean limited = false;
        List<String> missing = new ArrayList<>();
        for (String model : models) {
            try {
                JSONObject body = new JSONObject();
                body.put("system_instruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
                JSONArray contents = new JSONArray();
                for (Msg m : msgs) {
                    JSONArray parts = new JSONArray();
                    parts.put(new JSONObject().put("text", m.text.isEmpty() ? " " : m.text));
                    for (Img im : m.images) parts.put(new JSONObject().put("inline_data", new JSONObject().put("mime_type", im.mime).put("data", im.b64)));
                    contents.put(new JSONObject().put("role", "user".equals(m.role) ? "user" : "model").put("parts", parts));
                }
                body.put("contents", contents);
                body.put("generationConfig", new JSONObject().put("temperature", 0.2).put("maxOutputTokens", 8192));
                AiHelper.Http h = AiHelper.post("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent",
                        new String[][]{{"x-goog-api-key", cfg.key.trim()}}, body.toString());
                if (h.code == 200) {
                    JSONArray cands = new JSONObject(h.body).optJSONArray("candidates");
                    if (cands == null || cands.length() == 0) throw new AiHelper.AiException("AI ne jawab nahi diya (blocked ya khali). Dobara try karo.");
                    JSONObject content = cands.getJSONObject(0).optJSONObject("content");
                    JSONArray parts = content == null ? null : content.optJSONArray("parts");
                    StringBuilder sb = new StringBuilder();
                    if (parts != null) for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
                    if (sb.toString().trim().isEmpty()) throw new AiHelper.AiException("AI ka jawab khali aaya. Dobara try karo.");
                    Reply r = new Reply();
                    r.text = sb.toString();
                    r.model = model;
                    return r;
                }
                String em = AiHelper.errMsg(h.body);
                if (h.code == 400 && AiHelper.mentions(em, "api key not valid", "api_key_invalid")) throw new AiHelper.AiException("API key galat hai. AI setup me dobara paste karo.");
                if (h.code == 404 || (h.code == 400 && AiHelper.mentions(em, "not found", "not supported for generatecontent", "no longer available"))
                        || (h.code == 403 && AiHelper.mentions(em, "no longer", "not available", "access to"))) {
                    missing.add(model);
                    continue;
                }
                if (h.code == 401 || (h.code == 403 && AiHelper.mentions(em, "api key", "permission", "denied", "leaked"))) throw new AiHelper.AiException("Key ne kaam nahi kiya (" + h.code + "): " + em);
                if (h.code == 429) {
                    limited = true;
                    continue;
                }
                throw new AiHelper.AiException("Gemini error " + h.code + ": " + em);
            } catch (AiHelper.AiException e) {
                throw e;
            } catch (Exception e) {
                throw new AiHelper.AiException("Gemini ka jawab samajh nahi aaya: " + e);
            }
        }
        if (limited) throw new Limited("Gemini ki free limit puri ho gayi. Thodi der / kal try karo.");
        throw new AiHelper.AiException("Ye models is key se nahi chale: " + missing + ". AI setup me \"Model\" me koi chalne wala naam daalo.");
    }

    // ------------------------------------------------------------------ Claude
    private static Reply claude(AiHelper.Config cfg, String system, List<Msg> msgs) throws AiHelper.AiException, Limited {
        String model = cfg.model != null && cfg.model.trim().length() > 0 ? cfg.model.trim() : AiHelper.CLAUDE_MODEL;
        try {
            JSONObject body = new JSONObject();
            body.put("model", model);
            body.put("max_tokens", 4096);
            body.put("system", system);
            JSONArray arr = new JSONArray();
            for (Msg m : msgs) {
                JSONArray blocks = new JSONArray();
                for (Img im : m.images) {
                    blocks.put(new JSONObject().put("type", "image").put("source", new JSONObject().put("type", "base64").put("media_type", im.mime).put("data", im.b64)));
                }
                blocks.put(new JSONObject().put("type", "text").put("text", m.text.isEmpty() ? " " : m.text));
                arr.put(new JSONObject().put("role", m.role).put("content", blocks));
            }
            body.put("messages", arr);
            AiHelper.Http h = AiHelper.post("https://api.anthropic.com/v1/messages", new String[][]{{"x-api-key", cfg.key.trim()}, {"anthropic-version", "2023-06-01"}}, body.toString());
            if (h.code == 200) {
                JSONArray content = new JSONObject(h.body).optJSONArray("content");
                StringBuilder sb = new StringBuilder();
                if (content != null) for (int i = 0; i < content.length(); i++) {
                    JSONObject b = content.getJSONObject(i);
                    if ("text".equals(b.optString("type"))) sb.append(b.optString("text", ""));
                }
                Reply r = new Reply();
                r.text = sb.toString();
                r.model = model;
                if (r.text.trim().isEmpty()) throw new AiHelper.AiException("Claude ka jawab khali aaya. Dobara try karo.");
                return r;
            }
            String em = AiHelper.errMsg(h.body);
            if (h.code == 401) throw new AiHelper.AiException("Claude API key galat hai. AI setup me dobara paste karo.");
            if (h.code == 429) throw new Limited("Claude ki limit puri ho gayi (rate / spend limit). Thodi der baad ya limit badhakar try karo.");
            if (h.code == 400 && AiHelper.mentions(em, "credit", "balance", "billing", "spend")) throw new AiHelper.AiException("Claude credit / spend limit khatam: " + em);
            if (h.code == 404) throw new AiHelper.AiException("Model \"" + model + "\" nahi mila. AI setup me sahi model naam daalo.");
            throw new AiHelper.AiException("Claude error " + h.code + ": " + em);
        } catch (AiHelper.AiException | Limited e) {
            throw e;
        } catch (Exception e) {
            throw new AiHelper.AiException("Claude ka jawab samajh nahi aaya: " + e);
        }
    }

    // ------------------------------------------------------------------ Groq / OpenRouter / Mistral / Cerebras (OpenAI-style)
    private static Reply compat(AiHelper.Config cfg, AiHelper.Prov p, String system, List<Msg> msgs) throws AiHelper.AiException, Limited {
        List<String> models = AiHelper.compatCandidates(cfg, p);
        boolean limited = false;
        List<String> missing = new ArrayList<>();
        boolean images = hasImages(msgs);
        for (String model : models) {
            for (int pass = 0; pass < (images ? 2 : 1); pass++) {
                boolean withImages = images && pass == 0;
                try {
                    JSONObject body = new JSONObject();
                    body.put("model", model);
                    body.put("temperature", 0.2);
                    body.put("max_tokens", 4096);
                    JSONArray arr = new JSONArray();
                    arr.put(new JSONObject().put("role", "system").put("content", system));
                    for (Msg m : msgs) {
                        if (withImages && !m.images.isEmpty()) {
                            JSONArray parts = new JSONArray();
                            parts.put(new JSONObject().put("type", "text").put("text", m.text.isEmpty() ? " " : m.text));
                            for (Img im : m.images) parts.put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject().put("url", "data:" + im.mime + ";base64," + im.b64)));
                            arr.put(new JSONObject().put("role", m.role).put("content", parts));
                        } else {
                            String t = m.text;
                            if (!m.images.isEmpty()) t += "\n[" + m.images.size() + " image(s) attached, but this model cannot see images]";
                            arr.put(new JSONObject().put("role", m.role).put("content", t));
                        }
                    }
                    body.put("messages", arr);
                    AiHelper.Http h = AiHelper.post(p.base + "/chat/completions", new String[][]{{"Authorization", "Bearer " + cfg.key.trim()}}, body.toString());
                    if (h.code == 200) {
                        JSONArray ch = new JSONObject(h.body).optJSONArray("choices");
                        JSONObject msg = ch == null || ch.length() == 0 ? null : ch.getJSONObject(0).optJSONObject("message");
                        String text = msg == null ? "" : msg.optString("content", "");
                        if (text.trim().isEmpty()) break; // empty answer: next model
                        Reply r = new Reply();
                        r.text = text;
                        r.model = model;
                        r.visionDropped = images && !withImages;
                        return r;
                    }
                    String em = AiHelper.errMsg(h.body);
                    if (h.code == 401) throw new AiHelper.AiException(p.label + " key galat hai. AI setup me dobara paste karo.");
                    if (h.code == 402) throw new AiHelper.AiException(p.label + " me credit khatam: " + em);
                    if (h.code == 429 || h.code == 413) {
                        limited = true;
                        break;
                    }
                    if (h.code == 404 || h.code == 400 || h.code == 403 || h.code == 422) {
                        if (withImages) continue; // maybe the model has no vision: repeat without the images
                        missing.add(model);
                        break;
                    }
                    throw new AiHelper.AiException(p.label + " error " + h.code + ": " + em);
                } catch (AiHelper.AiException e) {
                    throw e;
                } catch (Exception e) {
                    throw new AiHelper.AiException(p.label + " ka jawab samajh nahi aaya: " + e);
                }
            }
        }
        if (limited) throw new Limited(p.label + " ki free limit puri ho gayi (ya message bahut bada hai). Thodi der ruko, doosra provider chuno, ya Gemini try karo.");
        throw new AiHelper.AiException("Ye models " + p.label + " pe nahi chale: " + missing + ". AI setup me \"Model\" me koi chalne wala naam daalo.");
    }
}
