package com.chanit.featuremerger.core;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.reference.FieldReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.iface.reference.StringReference;
import com.android.tools.smali.dexlib2.iface.reference.TypeReference;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Reads an APK without any native tools: manifest, resources, dex bytecode.
 * Finds overlay features (services that draw windows), their controls, how risky they are to move,
 * and everything that is switched off (hidden / disabled controls and components).
 */
public final class ApkAnalyzer {
    private ApkAnalyzer() {}

    public interface Progress { void update(int pct, String msg); }

    private static final String[] LIB = {
            "Landroid/", "Landroidx/", "Lkotlin/", "Lkotlinx/", "Ljava/", "Ljavax/", "Ldalvik/", "Lcom/google/", "Lcom/android/",
            "Lorg/jetbrains/", "Lorg/intellij/", "Lcom/squareup/", "Lokhttp3/", "Lokio/", "Lretrofit2/", "Lorg/apache/",
            "Lcom/facebook/", "Lcom/bumptech/", "Lio/reactivex/", "Lorg/greenrobot/", "Lcom/unity3d/", "Lcom/applovin/",
            "Lcom/ironsource/", "Lcom/mbridge/", "Lcom/vungle/", "Lcom/chartboost/", "Lcom/adcolony/", "Lcom/startapp/",
            "Lcom/mopub/", "Lorg/json/", "Lorg/w3c/", "Lorg/xml/", "Lcom/airbnb/", "Lio/grpc/", "Lcom/crashlytics/", "Lio/fabric/"
    };
    private static final String[] LICENSE_WORDS = {"license", "licence", "login", "password", "passwd", "token", "expire", "expiry",
            "activation", "activate", "premium", "subscription", "serial", "vip", "unlock key"};
    private static final int[] OVERLAY_TYPES = {2038, 2002, 2003, 2010, 2006, 2007};

    private static final class CI {
        String type, sup;
        boolean wm, ovType, vpnEst, vpnPrep, net, lib, refl;
        int lic;
        String[] refs = new String[0];
        int[] res = new int[0];
        List<String> urls = new ArrayList<>();
    }

    private static final class Comp {
        String tag, name, type, permission;
        boolean enabled = true;
    }

    private static final class Agg {
        boolean wm, ovType, vpnEst, vpnPrep, vpnSub, net, lib, refl;
        int lic, classes;
        Set<String> urls = new LinkedHashSet<>();
        Set<Integer> layoutIds = new LinkedHashSet<>();
    }

    // ------------------------------------------------------------------ public helpers
    public static boolean isToggle(String tag) {
        String t = tag.toLowerCase();
        return !t.contains("radio") && (t.contains("switch") || t.contains("checkbox") || t.contains("togglebutton"));
    }

    static boolean isInteractiveTag(String tag) {
        String t = tag.toLowerCase();
        return t.contains("button") || t.contains("switch") || t.contains("checkbox") || t.contains("toggle")
                || t.contains("seekbar") || t.contains("slider") || t.contains("spinner") || t.contains("edittext");
    }

    static String simple(String tag) {
        int i = tag.lastIndexOf('.');
        return i >= 0 ? tag.substring(i + 1) : tag;
    }

    private static String full(String pkg, String n) {
        if (n == null) return null;
        if (n.startsWith(".")) return pkg + n;
        if (n.indexOf('.') < 0) return pkg + "." + n;
        return n;
    }

    private static String desc(String dotted) { return "L" + dotted.replace('.', '/') + ";"; }

    private static boolean isLib(String t) {
        for (String p : LIB) if (t.startsWith(p)) return true;
        return false;
    }

    private static String bare(String t) {
        int i = 0;
        while (i < t.length() && t.charAt(i) == '[') i++;
        return t.substring(i);
    }

    // ------------------------------------------------------------------ main entry
    /**
     * Never throws. Whatever cannot be read is skipped and mentioned in info.notes, the APK is always returned,
     * so every imported APK shows up in the list (at worst with its name, package, size and icon only).
     */
    public static Model.Apk analyze(Context ctx, File apk, Progress pr) {
        Model.Apk info = new Model.Apk();
        info.path = apk.getAbsolutePath();
        info.size = apk.length();
        info.stamp = apk.lastModified();
        info.label = apk.getName();
        info.abiOk = true;
        step(pr, 2, "Reading manifest");
        try {
            deep(ctx, apk, pr, info);
        } catch (Throwable t) {
            info.notes.add("Only partly analyzed (" + brief(t) + "). The APK is added anyway.");
        }
        if (info.label == null || info.label.isEmpty()) info.label = apk.getName();
        step(pr, 100, "Done");
        return info;
    }

    private static void step(Progress pr, int p, String m) {
        try { if (pr != null) pr.update(p, m); } catch (Throwable ignored) { }
    }

    /** Short one-line description of an error with the first stack frames, for notes and the Log tab. */
    public static String brief(Throwable t) {
        StringBuilder sb = new StringBuilder(t.getClass().getSimpleName());
        if (t.getMessage() != null) sb.append(": ").append(t.getMessage());
        StackTraceElement[] st = t.getStackTrace();
        if (st != null) {
            int n = 0;
            for (StackTraceElement e : st) {
                String c = e.getClassName();
                sb.append(n == 0 ? " at " : " < ").append(c.substring(c.lastIndexOf('.') + 1))
                        .append('.').append(e.getMethodName()).append(':').append(e.getLineNumber());
                if (++n >= 4) break;
            }
        }
        return sb.toString();
    }

    private static String[] phoneAbis() {
        String[] a = null;
        try { a = Build.SUPPORTED_ABIS; } catch (Throwable ignored) { }
        return a == null ? new String[0] : a;
    }

    private static void deep(Context ctx, File apk, Progress pr, Model.Apk info) throws Exception {
        // The system's own reader first: gives name, icon, package and version even when our parser cannot cope.
        readLabelAndIcon(ctx, info);

        try (ZipFile zf = new ZipFile(apk)) {
            List<Comp> comps = new ArrayList<>();
            try {
                readManifest(zf, info, comps);
            } catch (Throwable t) {
                info.notes.add("Manifest could not be read completely (" + brief(t) + ").");
            }

            List<String> dexNames = new ArrayList<>();
            Set<String> abis = new LinkedHashSet<>();
            try {
                for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                    ZipEntry ze = en.nextElement();
                    String n = ze == null ? null : ze.getName();
                    if (n == null) continue;
                    if (n.matches("classes\\d*\\.dex")) dexNames.add(n);
                    else if (n.startsWith("lib/")) {
                        String[] sp = n.split("/");
                        if (sp != null && sp.length >= 3) abis.add(sp[1]);
                    }
                }
            } catch (Throwable t) {
                info.notes.add("Could not list the files inside the APK (" + brief(t) + ").");
            }
            info.abis.addAll(abis);
            info.dexCount = dexNames.size();
            info.abiOk = abis.isEmpty();
            for (String s : phoneAbis()) if (s != null && abis.contains(s)) info.abiOk = true;

            Arsc arsc = null;
            try {
                ZipEntry ae = zf.getEntry("resources.arsc");
                if (ae != null) arsc = Arsc.parse(ApkZip.readAll(zf, ae));
            } catch (Throwable e) {
                arsc = null;
                info.notes.add("Resources could not be read; names will be shown as ids.");
            }

            // ---- dex scan (every dex and every class on its own, one bad one never stops the rest)
            Map<String, CI> map = new HashMap<>();
            int idx = 0, badDex = 0, badClass = 0;
            for (String dn : dexNames) {
                idx++;
                step(pr, 8 + (int) (55.0 * idx / Math.max(1, dexNames.size())), "Scanning " + dn);
                File tmp = new File(ctx.getCacheDir(), "scan_" + idx + ".dex");
                try {
                    ZipEntry de = zf.getEntry(dn);
                    if (de == null) continue;
                    try (InputStream in = zf.getInputStream(de); FileOutputStream out = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[1 << 16];
                        int r;
                        while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                    }
                    DexFile df = DexFileFactory.loadDexFile(tmp, Opcodes.getDefault());
                    for (ClassDef cd : df.getClasses()) {
                        try {
                            if (isLib(cd.getType())) continue;
                            map.put(cd.getType(), scan(cd, arsc));
                        } catch (Throwable t) {
                            badClass++;
                        }
                    }
                } catch (Throwable t) {
                    badDex++;
                    info.notes.add(dn + " could not be fully read (" + brief(t) + ").");
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            }
            if (badClass > 0) info.notes.add(badClass + " class(es) were skipped because their code could not be read.");
            info.classCount = map.size();
            int obf = 0;
            for (String t : map.keySet()) {
                String s = t.substring(t.lastIndexOf('/') + 1).replace(";", "");
                int d = s.indexOf('$');
                if (d > 0) s = s.substring(0, d);
                if (s.length() <= 2) obf++;
            }
            info.obfuscation = map.isEmpty() ? 0 : obf * 100 / map.size();

            step(pr, 66, "Finding overlay features");
            Set<String> compTypes = new HashSet<>();
            for (Comp c : comps) compTypes.add(c.type);

            Set<String> covered = new HashSet<>();
            for (Comp c : comps) {
                try {
                    if (!"service".equals(c.tag) || !map.containsKey(c.type)) continue;
                    String ext = externalSuper(c.type, map);
                    if ("Landroid/net/VpnService;".equals(ext) || "android.permission.BIND_VPN_SERVICE".equals(c.permission)) {
                        info.vpn = true;
                        info.vpnClass = c.name;
                    }
                    Set<String> clo = closure(c.type, map, compTypes, 400);
                    Agg ag = aggregate(clo, c.type, map, compTypes);
                    if (!ag.wm) continue;
                    covered.addAll(clo);
                    Model.Feature f = new Model.Feature();
                    f.id = c.type;
                    f.kind = "SERVICE";
                    f.serviceName = c.name;
                    f.classCount = ag.classes;
                    f.movable = "Landroid/app/Service;".equals(ext) && c.enabled;
                    fillControls(f, ag, zf, arsc);
                    f.label = labelFor(c.type, f);
                    judge(f, ag, ext, info, true);
                    if (!c.enabled) f.reasons.add("This service is disabled in the manifest (see hidden items).");
                    info.features.add(f);
                } catch (Throwable t) {
                    info.notes.add("Service " + simple(c.name) + " could not be analyzed (" + brief(t) + ").");
                }
            }
            // overlay code that is not inside a service
            try {
                Map<String, Boolean> others = new LinkedHashMap<>();
                for (CI ci : map.values()) {
                    if (!ci.wm || covered.contains(ci.type)) continue;
                    String o = ci.type;
                    int d = o.indexOf('$');
                    if (d > 0) o = o.substring(0, d) + ";";
                    others.put(o, true);
                }
                int shown = 0;
                for (String o : others.keySet()) {
                    if (shown++ >= 8) break;
                    try {
                        Set<String> clo = closure(o, map, compTypes, 120);
                        Agg ag = aggregate(clo, o, map, compTypes);
                        Model.Feature f = new Model.Feature();
                        f.id = o;
                        f.kind = "OTHER";
                        f.movable = false;
                        f.classCount = ag.classes;
                        fillControls(f, ag, zf, arsc);
                        f.label = labelFor(o, f);
                        judge(f, ag, externalSuper(o, map), info, false);
                        info.features.add(f);
                    } catch (Throwable t) {
                        info.notes.add("Overlay code " + simple(o) + " could not be analyzed (" + brief(t) + ").");
                    }
                }
            } catch (Throwable t) {
                info.notes.add("Overlay search stopped early (" + brief(t) + ").");
            }

            step(pr, 82, "Looking for switched-off items");
            try {
                for (Comp c : comps) {
                    if (c.enabled) continue;
                    Model.Hidden h = new Model.Hidden();
                    h.kind = "COMPONENT";
                    h.tag = c.tag;
                    h.name = c.name;
                    h.how = "disabled";
                    h.label = prettyName(c.name);
                    h.detail = "Disabled " + c.tag + " in the manifest: " + simple(c.name);
                    info.hidden.add(h);
                }
                if (arsc != null) scanHidden(zf, arsc, info);
            } catch (Throwable t) {
                info.notes.add("Switched-off scan stopped early (" + brief(t) + ").");
            }
            if (info.vpn) info.notes.add("VPN engine found: " + simple(info.vpnClass) + ". The engine itself cannot be moved; overlay features that drive it are marked red.");
            if (!info.abiOk) {
                String[] pa = phoneAbis();
                info.notes.add("Native libraries do not include this phone's CPU (" + (pa.length > 0 ? pa[0] : "unknown") + ").");
            }
            if (info.obfuscation > 60) info.notes.add("Heavily obfuscated (" + info.obfuscation + "% short class names); names are guessed from layouts.");
            if (badDex > 0 && map.isEmpty()) info.notes.add("No code could be read, so features are not listed. The APK can still be used as a VPN app or game.");
        }
    }

    private static void readManifest(ZipFile zf, Model.Apk info, List<Comp> comps) throws Exception {
        ZipEntry me = zf.getEntry("AndroidManifest.xml");
        if (me == null) throw new IOException("AndroidManifest.xml is missing");
        Axml mf = Axml.parse(ApkZip.readAll(zf, me));
        String pkg = mf.root.plain("package") != null ? mf.root.plain("package").text() : null;
        if (pkg != null) info.pkg = pkg;
        else if (info.pkg == null) info.pkg = "unknown";
        pkg = info.pkg;
        String vn = mf.root.text("versionName");
        if (vn != null) info.versionName = vn;
        try { info.versionCode = Integer.decode(String.valueOf(mf.root.text("versionCode"))); } catch (Exception ignored) { }
        Axml.Elem sdk = mf.root.child("uses-sdk");
        if (sdk != null) {
            try { info.minSdk = Integer.decode(sdk.text("minSdkVersion")); } catch (Exception ignored) { }
            try { info.targetSdk = Integer.decode(sdk.text("targetSdkVersion")); } catch (Exception ignored) { }
        }
        for (Axml.Elem k : mf.root.kids) {
            if ("uses-permission".equals(k.name) && k.text("name") != null && !info.permissions.contains(k.text("name")))
                info.permissions.add(k.text("name"));
        }
        info.overlayPerm = info.permissions.contains("android.permission.SYSTEM_ALERT_WINDOW");

        Axml.Elem app = mf.root.child("application");
        if (app != null) {
            if (app.text("name") != null) info.appClass = full(pkg, app.text("name"));
            for (Axml.Elem k : app.kids) {
                if (!("service".equals(k.name) || "activity".equals(k.name) || "receiver".equals(k.name)
                        || "provider".equals(k.name) || "activity-alias".equals(k.name))) continue;
                String n = full(pkg, k.text("name"));
                if (n == null) continue;
                Comp c = new Comp();
                c.tag = k.name;
                c.name = n;
                c.type = desc(n);
                c.permission = k.text("permission");
                Axml.Attr en = k.attr("enabled");
                c.enabled = !(en != null && en.type == Axml.T_BOOL && en.data == 0);
                comps.add(c);
            }
        }
    }

    // ------------------------------------------------------------------ label + icon
    private static void readLabelAndIcon(Context ctx, Model.Apk info) {
        try {
            PackageManager pm = ctx.getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(info.path, 0);
            if (pi == null || pi.applicationInfo == null) return;
            ApplicationInfo ai = pi.applicationInfo;
            if (pi.packageName != null) info.pkg = pi.packageName;
            if (pi.versionName != null) info.versionName = pi.versionName;
            ai.sourceDir = info.path;
            ai.publicSourceDir = info.path;
            CharSequence l = ai.loadLabel(pm);
            if (l != null && l.length() > 0) info.label = l.toString();
            Drawable d = ai.loadIcon(pm);
            if (d != null) {
                Bitmap bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bm);
                d.setBounds(0, 0, 96, 96);
                d.draw(c);
                File dir = new File(ctx.getFilesDir(), "icons");
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                File f = new File(dir, Integer.toHexString(info.path.hashCode()) + ".png");
                try (FileOutputStream o = new FileOutputStream(f)) {
                    bm.compress(Bitmap.CompressFormat.PNG, 100, o);
                }
                info.iconPath = f.getAbsolutePath();
            }
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ dex scan
    private static CI scan(ClassDef cd, Arsc arsc) {
        CI ci = new CI();
        ci.type = cd.getType();
        ci.sup = cd.getSuperclass();
        Set<String> refs = new HashSet<>();
        Set<Integer> res = new HashSet<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation mi = m.getImplementation();
            if (mi == null) continue;
            for (Instruction ins : mi.getInstructions()) {
                if (ins instanceof ReferenceInstruction) {
                    Reference r = ((ReferenceInstruction) ins).getReference();
                    if (r instanceof MethodReference) {
                        MethodReference mr = (MethodReference) r;
                        String dc = bare(mr.getDefiningClass());
                        String nm = mr.getName();
                        if (("Landroid/view/WindowManager;".equals(dc) || "Landroid/view/ViewManager;".equals(dc)) && "addView".equals(nm)) ci.wm = true;
                        else if ("Landroid/net/VpnService$Builder;".equals(dc) && "establish".equals(nm)) ci.vpnEst = true;
                        else if ("Landroid/net/VpnService;".equals(dc) && "prepare".equals(nm)) ci.vpnPrep = true;
                        else if ("Ljava/lang/System;".equals(dc) && (nm.equals("loadLibrary") || nm.equals("load"))) ci.lib = true;
                        else if (("Ljava/lang/reflect/Method;".equals(dc) && nm.equals("invoke")) || ("Ljava/lang/Class;".equals(dc) && nm.equals("forName"))) ci.refl = true;
                        if (dc.startsWith("Ljava/net/Socket") || dc.equals("Ljava/net/DatagramSocket;") || dc.equals("Ljava/net/HttpURLConnection;")
                                || dc.startsWith("Ljavax/net/ssl/") || dc.startsWith("Lokhttp3/") || dc.startsWith("Ljava/nio/channels/SocketChannel")
                                || dc.startsWith("Ljava/nio/channels/DatagramChannel")) ci.net = true;
                        if (!isLib(dc)) refs.add(dc);
                    } else if (r instanceof FieldReference) {
                        String dc = bare(((FieldReference) r).getDefiningClass());
                        if (!isLib(dc)) refs.add(dc);
                    } else if (r instanceof TypeReference) {
                        String t = bare(((TypeReference) r).getType());
                        if (!isLib(t)) refs.add(t);
                    } else if (r instanceof StringReference) {
                        String s = ((StringReference) r).getString();
                        if (s.startsWith("http://") || s.startsWith("https://")) {
                            if (ci.urls.size() < 6) ci.urls.add(s);
                        } else if (s.length() <= 60) {
                            String l = s.toLowerCase();
                            for (String w : LICENSE_WORDS) if (l.contains(w)) { ci.lic++; break; }
                        }
                    }
                } else if (ins instanceof NarrowLiteralInstruction) {
                    int v = ((NarrowLiteralInstruction) ins).getNarrowLiteral();
                    if ((v >>> 24) == 0x7f) {
                        if (arsc != null) {
                            Arsc.Entry e = arsc.get(v);
                            if (e != null && ("layout".equals(e.type) || "id".equals(e.type))) res.add(v);
                        }
                    } else {
                        for (int t : OVERLAY_TYPES) if (v == t) ci.ovType = true;
                    }
                }
            }
        }
        ci.refs = refs.toArray(new String[0]);
        ci.res = new int[res.size()];
        int i = 0;
        for (int v : res) ci.res[i++] = v;
        return ci;
    }

    private static String externalSuper(String type, Map<String, CI> map) {
        String t = type;
        for (int i = 0; i < 14; i++) {
            CI ci = map.get(t);
            if (ci == null) return t;
            if (ci.sup == null) return "Ljava/lang/Object;";
            t = ci.sup;
        }
        return t;
    }

    private static Set<String> closure(String start, Map<String, CI> map, Set<String> stop, int limit) {
        Set<String> seen = new LinkedHashSet<>();
        ArrayDeque<String> q = new ArrayDeque<>();
        q.add(start);
        seen.add(start);
        while (!q.isEmpty() && seen.size() < limit) {
            CI ci = map.get(q.poll());
            if (ci == null) continue;
            for (String r : ci.refs) {
                if (seen.contains(r) || !map.containsKey(r)) continue;
                seen.add(r);
                if (!stop.contains(r)) q.add(r);
            }
        }
        // inner classes of the start class
        String base = start.substring(0, start.length() - 1) + "$";
        for (String t : map.keySet()) if (t.startsWith(base)) seen.add(t);
        return seen;
    }

    private static Agg aggregate(Set<String> clo, String start, Map<String, CI> map, Set<String> stop) {
        Agg a = new Agg();
        for (String t : clo) {
            if (stop.contains(t) && !t.equals(start)) continue;
            CI c = map.get(t);
            if (c == null) continue;
            a.classes++;
            a.wm |= c.wm; a.ovType |= c.ovType; a.vpnEst |= c.vpnEst; a.vpnPrep |= c.vpnPrep;
            a.net |= c.net; a.lib |= c.lib; a.refl |= c.refl; a.lic += c.lic;
            a.urls.addAll(c.urls);
            for (int v : c.res) a.layoutIds.add(v);
            if ("Landroid/net/VpnService;".equals(externalSuper(t, map))) a.vpnSub = true;
        }
        return a;
    }

    // ------------------------------------------------------------------ controls, labels, verdict
    private static void fillControls(Model.Feature f, Agg ag, ZipFile zf, Arsc arsc) {
        if (arsc == null) return;
        Set<String> seen = new HashSet<>();
        for (int id : ag.layoutIds) {
            Arsc.Entry le = arsc.get(id);
            if (le == null || !"layout".equals(le.type)) continue;
            ArrayList<String> paths = new ArrayList<>();
            for (String s : le.strings) if (s.endsWith(".xml")) paths.add(s);
            if (paths.isEmpty()) continue;
            f.layouts.add(le.name);
            f.layoutFiles.put(le.name, paths);
            try {
                ZipEntry ze = zf.getEntry(paths.get(0));
                if (ze == null) continue;
                Axml x = Axml.parse(ApkZip.readAll(zf, ze));
                final String lname = le.name;
                final ArrayList<String> lp = paths;
                x.root.walk(el -> {
                    Axml.Attr ida = el.attr("id");
                    if (ida == null || ida.type != Axml.T_REF) return;
                    boolean click = el.attr("onClick") != null || "true".equals(el.text("clickable"));
                    if (!isInteractiveTag(el.name) && !click) return;
                    if (!seen.add(lname + "#" + ida.data)) return;
                    Model.Control c = new Model.Control();
                    c.viewId = ida.data;
                    c.idName = arsc.nameOf(ida.data);
                    c.tag = simple(el.name);
                    c.label = labelOf(el, arsc);
                    c.layout = lname;
                    c.layoutPaths = lp;
                    f.controls.add(c);
                });
            } catch (Exception ignored) { }
        }
    }

    static String labelOf(Axml.Elem el, Arsc arsc) {
        for (String an : new String[]{"text", "contentDescription"}) {
            Axml.Attr a = el.attr(an);
            if (a == null) continue;
            String s = null;
            if (a.type == Axml.T_STRING) s = a.str;
            else if (a.type == Axml.T_REF && arsc != null) s = arsc.firstString(a.data);
            if (s != null && !s.trim().isEmpty()) return s.trim();
        }
        Axml.Attr ida = el.attr("id");
        if (ida != null && arsc != null) return prettyName(arsc.nameOf(ida.data));
        return simple(el.name);
    }

    private static String prettyName(String n) {
        String s = simple(n);
        s = s.replace('_', ' ').replace('$', ' ');
        return s.replaceAll("([a-z0-9])([A-Z])", "$1 $2").trim();
    }

    private static String labelFor(String type, Model.Feature f) {
        String s = type.substring(type.lastIndexOf('/') + 1).replace(";", "");
        int d = s.indexOf('$');
        if (d > 0) s = s.substring(0, d);
        s = s.replaceAll("(Service|Overlay|Impl)$", "");
        if (s.length() > 2) return s.replaceAll("([a-z0-9])([A-Z])", "$1 $2");
        if (!f.layouts.isEmpty()) return "Overlay (" + f.layouts.get(0).replace('_', ' ') + ")";
        return "Overlay " + s;
    }

    private static void judge(Model.Feature f, Agg ag, String ext, Model.Apk info, boolean service) {
        int lvl = Model.GREEN;
        if (!service) {
            lvl = Model.RED;
            f.reasons.add("Built inside an Activity or other code, so it cannot be moved yet. Its controls can still be hidden.");
        } else if (!"Landroid/app/Service;".equals(ext)) {
            lvl = Model.RED;
            f.reasons.add("Special service type (" + simple(ext.replace('/', '.').replace(";", "")) + "), cannot run inside another app.");
        }
        if (ag.vpnSub || ag.vpnEst || ag.vpnPrep) {
            lvl = Model.RED;
            f.reasons.add("Drives this app's own VPN engine, which would not exist in the other app.");
        }
        if (service) {
            if (ag.lib) {
                if (!info.abiOk) {
                    lvl = Model.RED;
                    f.reasons.add("Needs a native library that does not match this phone's CPU.");
                } else {
                    lvl = Math.max(lvl, Model.AMBER);
                    f.reasons.add("Uses a native library; it is copied along from the source app.");
                }
            }
            if (ag.net && !ag.urls.isEmpty() && ag.lic >= 2) {
                lvl = Model.RED;
                f.reasons.add("Checks a license or login on a server: " + host(ag.urls) + ".");
            } else if (ag.net && !ag.urls.isEmpty()) {
                lvl = Math.max(lvl, Model.AMBER);
                f.reasons.add("Talks to a server: " + host(ag.urls) + ".");
            } else if (ag.lic >= 2) {
                lvl = Math.max(lvl, Model.AMBER);
                f.reasons.add("Has login or license checks in its code.");
            }
            if (info.obfuscation > 60) {
                lvl = Math.max(lvl, Model.AMBER);
                f.reasons.add("The app is heavily obfuscated, so tracing may miss a few classes.");
            }
            if (lvl == Model.GREEN) f.reasons.add("Self-contained overlay. Should work the same after the move.");
        }
        f.level = lvl;
    }

    private static String host(Set<String> urls) {
        List<String> hosts = new ArrayList<>();
        for (String u : urls) {
            try {
                String h = u.replaceFirst("^https?://", "");
                int s = h.indexOf('/');
                if (s > 0) h = h.substring(0, s);
                if (!hosts.contains(h)) hosts.add(h);
            } catch (Exception ignored) { }
            if (hosts.size() >= 2) break;
        }
        return hosts.toString().replace("[", "").replace("]", "");
    }

    // ------------------------------------------------------------------ hidden / disabled controls
    private static void scanHidden(ZipFile zf, Arsc arsc, Model.Apk info) {
        Set<String> seen = new HashSet<>();
        for (Arsc.Entry le : arsc.byId.values()) {
            if (!"layout".equals(le.type) || info.hidden.size() > 120) continue;
            ArrayList<String> paths = new ArrayList<>();
            for (String s : le.strings) if (s.endsWith(".xml")) paths.add(s);
            if (paths.isEmpty()) continue;
            try {
                ZipEntry ze = zf.getEntry(paths.get(0));
                if (ze == null) continue;
                Axml x = Axml.parse(ApkZip.readAll(zf, ze));
                final String lname = le.name;
                x.root.walk(el -> {
                    Axml.Attr ida = el.attr("id");
                    if (ida == null || ida.type != Axml.T_REF || !isInteractiveTag(el.name)) return;
                    String how = null;
                    Axml.Attr vis = el.attr("visibility");
                    if (vis != null && (vis.type == Axml.T_HEX || vis.type == Axml.T_DEC)) {
                        if (vis.data == 2) how = "gone";
                        else if (vis.data == 1) how = "invisible";
                    }
                    Axml.Attr en = el.attr("enabled");
                    if (how == null && en != null && en.type == Axml.T_BOOL && en.data == 0) how = "disabled";
                    if (how == null || !seen.add(lname + "#" + ida.data)) return;
                    Model.Hidden h = new Model.Hidden();
                    h.kind = "CONTROL";
                    h.how = how;
                    h.layout = lname;
                    h.viewId = ida.data;
                    h.layoutPaths = paths;
                    h.label = labelOf(el, arsc);
                    h.detail = simple(el.name) + " is " + how + " in layout " + lname;
                    info.hidden.add(h);
                });
            } catch (Exception ignored) { }
        }
    }
}
