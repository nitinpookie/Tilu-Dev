package com.chanit.featuremerger.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * XAPK / APKS / APKM are zip bundles: a base APK, split APKs (config.arm64_v8a.apk ...), a manifest and sometimes OBB files.
 * The bundle is unpacked into files/xapk/NAME/, the base APK is what gets edited. On export the edited base and every other
 * split are signed with the same key (splits must share the signature of the base) and the bundle is zipped again.
 */
public final class Xapk {
    private Xapk() {}

    public static boolean isBundleName(String name) {
        String n = name == null ? "" : name.toLowerCase();
        return n.endsWith(".xapk") || n.endsWith(".apks") || n.endsWith(".apkm");
    }

    public static File dir(File filesDir, String id) { return new File(new File(filesDir, "xapk"), id); }

    public static boolean isBundle(File filesDir, String id) { return dir(filesDir, id).isDirectory(); }

    /** Unpacks the bundle and returns the base APK inside the unpacked folder. */
    public static File unpack(File bundle, File target) throws IOException {
        deleteTree(target);
        //noinspection ResultOfMethodCallIgnored
        target.mkdirs();
        String root = target.getCanonicalPath() + File.separator;
        try (ZipFile zf = new ZipFile(bundle)) {
            byte[] buf = new byte[1 << 16];
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                File f = new File(target, e.getName());
                if (!f.getCanonicalPath().startsWith(root)) continue; // never write outside the folder
                //noinspection ResultOfMethodCallIgnored
                f.getParentFile().mkdirs();
                try (InputStream in = zf.getInputStream(e); FileOutputStream o = new FileOutputStream(f)) {
                    int r;
                    while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                }
            }
        }
        File base = findBase(target);
        if (base == null) throw new IOException("No base APK found inside this bundle.");
        return base;
    }

    public static File findBase(File dir) {
        List<File> apks = new ArrayList<>();
        collect(dir, apks);
        File best = null;
        for (File f : apks) {
            String n = f.getName().toLowerCase();
            if (n.equals("base.apk")) return f;
        }
        for (File f : apks) {
            String n = f.getName().toLowerCase();
            if (n.startsWith("config.") || n.startsWith("split_") || n.contains("split_config") || n.contains(".config.")) continue;
            if (best == null || f.length() > best.length()) best = f;
        }
        if (best == null) for (File f : apks) if (best == null || f.length() > best.length()) best = f;
        return best;
    }

    private static void collect(File d, List<File> out) {
        File[] fs = d.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) collect(f, out);
            else if (f.getName().toLowerCase().endsWith(".apk")) out.add(f);
        }
    }

    /** Where the base APK sits inside the unpacked folder, e.g. "base.apk" or "com.x.apk". */
    public static String basePath(File dir) {
        File b = findBase(dir);
        if (b == null) return null;
        String root = dir.getAbsolutePath() + File.separator;
        String p = b.getAbsolutePath();
        return p.startsWith(root) ? p.substring(root.length()).replace(File.separatorChar, '/') : b.getName();
    }

    /**
     * Writes the bundle again: the entry basePath is replaced by editedBase (already signed), every other .apk is signed with the
     * key, all other files are copied as they are.
     */
    public static int repack(File dir, String basePath, File editedBase, File keyDir, File out, File tmp) throws Exception {
        List<File> all = new ArrayList<>();
        collectAll(dir, all);
        int signed = 0;
        try (ApkZip.Writer w = new ApkZip.Writer(out)) {
            String root = dir.getAbsolutePath() + File.separator;
            for (File f : all) {
                String name = f.getAbsolutePath().substring(root.length()).replace(File.separatorChar, '/');
                if (name.equals(basePath)) {
                    w.putFile(name, editedBase);
                } else if (name.toLowerCase().endsWith(".apk")) {
                    File s = new File(tmp, "split_signed_" + signed + ".apk");
                    Signer.sign(keyDir, f, s);
                    w.putFile(name, s);
                    //noinspection ResultOfMethodCallIgnored
                    s.delete();
                    signed++;
                } else {
                    w.put(name, readAll(f), false);
                }
            }
        }
        return signed;
    }

    private static void collectAll(File d, List<File> out) {
        File[] fs = d.listFiles();
        if (fs == null) return;
        java.util.Arrays.sort(fs);
        for (File f : fs) {
            if (f.isDirectory()) collectAll(f, out);
            else out.add(f);
        }
    }

    private static byte[] readAll(File f) throws IOException {
        byte[] b = new byte[(int) f.length()];
        try (InputStream in = new FileInputStream(f)) {
            int o = 0;
            while (o < b.length) {
                int r = in.read(b, o, b.length - o);
                if (r < 0) break;
                o += r;
            }
        }
        return b;
    }

    public static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    /** Short description of the split APKs for the AI / UI. */
    public static String describe(File dir) {
        List<File> apks = new ArrayList<>();
        collect(dir, apks);
        StringBuilder sb = new StringBuilder();
        for (File f : apks) sb.append(sb.length() > 0 ? ", " : "").append(f.getName());
        return apks.size() + " APK file(s): " + sb;
    }
}
