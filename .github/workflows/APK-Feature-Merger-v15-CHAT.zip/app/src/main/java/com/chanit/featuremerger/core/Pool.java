package com.chanit.featuremerger.core;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Reads and writes ResStringPool chunks (shared by binary XML and resources.arsc). */
final class Pool {
    private Pool() {}

    static final class Result {
        String[] strings;
        int size;
    }

    static int u16(byte[] b, int o) { return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8); }

    static int i32(byte[] b, int o) {
        return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8) | ((b[o + 2] & 0xff) << 16) | ((b[o + 3] & 0xff) << 24);
    }

    static Result read(byte[] b, int off) {
        if (u16(b, off) != 0x0001) throw new IllegalStateException("string pool expected at " + off);
        int hdr = u16(b, off + 2);
        int size = i32(b, off + 4);
        int count = i32(b, off + 8);
        int flags = i32(b, off + 16);
        int strStart = i32(b, off + 20);
        boolean utf8 = (flags & 0x100) != 0;
        String[] out = new String[count];
        for (int i = 0; i < count; i++) {
            int rel = i32(b, off + hdr + 4 * i);
            int p = off + strStart + rel;
            try {
                out[i] = utf8 ? readUtf8(b, p) : readUtf16(b, p);
            } catch (RuntimeException e) {
                out[i] = "";
            }
        }
        Result r = new Result();
        r.strings = out;
        r.size = size;
        return r;
    }

    private static String readUtf16(byte[] b, int p) {
        int len = u16(b, p);
        p += 2;
        if ((len & 0x8000) != 0) {
            len = ((len & 0x7fff) << 16) | u16(b, p);
            p += 2;
        }
        return new String(b, p, len * 2, StandardCharsets.UTF_16LE);
    }

    private static String readUtf8(byte[] b, int p) {
        int c = b[p++] & 0xff;
        if ((c & 0x80) != 0) p++; // utf-16 length, 2 bytes form (unused)
        int len = b[p++] & 0xff;
        if ((len & 0x80) != 0) len = ((len & 0x7f) << 8) | (b[p++] & 0xff);
        return new String(b, p, len, StandardCharsets.UTF_8);
    }

    /** Writes a UTF-16 pool chunk (always valid for every Android parser). */
    static byte[] write(List<String> strs) {
        int n = strs.size();
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offs = new int[n];
        for (int i = 0; i < n; i++) {
            offs[i] = data.size();
            String s = strs.get(i);
            int len = s.length();
            if (len > 0x7fff) {
                put16(data, 0x8000 | (len >> 16));
                put16(data, len & 0xffff);
            } else {
                put16(data, len);
            }
            byte[] c = s.getBytes(StandardCharsets.UTF_16LE);
            data.write(c, 0, c.length);
            put16(data, 0);
        }
        while (data.size() % 4 != 0) data.write(0);
        int strStart = 28 + 4 * n;
        int size = strStart + data.size();
        ByteBuffer bb = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        bb.putShort((short) 1).putShort((short) 28).putInt(size);
        bb.putInt(n).putInt(0).putInt(0).putInt(strStart).putInt(0);
        for (int i = 0; i < n; i++) bb.putInt(offs[i]);
        bb.put(data.toByteArray());
        return bb.array();
    }

    private static void put16(ByteArrayOutputStream o, int v) {
        o.write(v & 0xff);
        o.write((v >> 8) & 0xff);
    }
}
