package com.chanit.featuremerger.bridge;

public class FmShim2 extends FmShimBase {
    @Override protected int slot() { return 2; }
}
