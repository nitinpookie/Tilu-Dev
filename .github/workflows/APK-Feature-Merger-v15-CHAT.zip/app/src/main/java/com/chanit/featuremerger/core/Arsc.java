package com.chanit.featuremerger.core;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Read-only view of resources.arsc: resource id -> type, name and string values (all configs). */
public final class Arsc {
    public static final class Entry {
        public int id;
        public String type, name;
        public final List<String> strings = new ArrayList<>();
    }

    public final Map<Integer, Entry> byId = new HashMap<>();

    public Entry get(int id) { return byId.get(id); }

    public String nameOf(int id) {
        Entry e = byId.get(id);
        return e == null ? String.format("0x%08x", id) : e.name;
    }

    public String firstString(int id) {
        Entry e = byId.get(id);
        return (e == null || e.strings.isEmpty()) ? null : e.strings.get(0);
    }

    public static Arsc parse(byte[] buf) {
        ByteBuffer b = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
        if (Pool.u16(buf, 0) != 0x0002) throw new IllegalArgumentException("not resources.arsc");
        int total = Math.min(b.getInt(4), buf.length);
        int p = Pool.u16(buf, 2);
        String[] global = new String[0];
        Arsc a = new Arsc();
        while (p + 8 <= total) {
            int type = Pool.u16(buf, p);
            int size = b.getInt(p + 4);
            if (size < 8) break;
            if (type == 0x0001) global = Pool.read(buf, p).strings;
            else if (type == 0x0200) a.readPackage(buf, b, p, size, global);
            p += size;
        }
        return a;
    }

    private void readPackage(byte[] buf, ByteBuffer b, int p, int size, String[] global) {
        int pkgId = b.getInt(p + 8);
        int typeOff = b.getInt(p + 268);
        int keyOff = b.getInt(p + 276);
        String[] types = Pool.read(buf, p + typeOff).strings;
        String[] keys = Pool.read(buf, p + keyOff).strings;
        int q = p + Pool.u16(buf, p + 2);
        int end = p + size;
        while (q + 8 <= end) {
            int type = Pool.u16(buf, q);
            int hdr = Pool.u16(buf, q + 2);
            int csize = b.getInt(q + 4);
            if (csize < 8) break;
            if (type == 0x0201) readType(buf, b, q, hdr, pkgId, types, keys, global);
            q += csize;
        }
    }

    private void readType(byte[] buf, ByteBuffer b, int q, int hdr, int pkgId, String[] types, String[] keys, String[] global) {
        int typeId = buf[q + 8] & 0xff;
        int flags = buf[q + 9] & 0xff;
        int count = b.getInt(q + 12);
        int entriesStart = b.getInt(q + 16);
        String typeName = (typeId - 1 >= 0 && typeId - 1 < types.length) ? types[typeId - 1] : "type" + typeId;
        for (int i = 0; i < count; i++) {
            int index;
            long off;
            if ((flags & 0x01) != 0) { // sparse
                int w = q + hdr + 4 * i;
                index = Pool.u16(buf, w);
                off = (long) Pool.u16(buf, w + 2) * 4;
            } else if ((flags & 0x02) != 0) { // 16-bit offsets
                int v = Pool.u16(buf, q + hdr + 2 * i);
                if (v == 0xffff) continue;
                index = i;
                off = (long) v * 4;
            } else {
                long v = b.getInt(q + hdr + 4 * i) & 0xffffffffL;
                if (v == 0xffffffffL) continue;
                index = i;
                off = v;
            }
            int e = (int) (q + entriesStart + off);
            if (e + 8 > buf.length) continue;
            int first = Pool.u16(buf, e);
            int eflags = Pool.u16(buf, e + 2);
            int key, dtype, data;
            boolean complex = false;
            if ((eflags & 0x0008) != 0) { // compact entry
                key = first;
                dtype = (eflags >> 8) & 0xff;
                data = b.getInt(e + 4);
            } else {
                key = b.getInt(e + 4);
                complex = (eflags & 0x0001) != 0;
                if (complex) { dtype = 0; data = 0; }
                else {
                    if (e + 16 > buf.length) continue;
                    dtype = buf[e + 11] & 0xff;
                    data = b.getInt(e + 12);
                }
            }
            int id = (pkgId << 24) | (typeId << 16) | index;
            Entry en = byId.get(id);
            if (en == null) {
                en = new Entry();
                en.id = id;
                en.type = typeName;
                en.name = (key >= 0 && key < keys.length) ? keys[key] : "res" + index;
                byId.put(id, en);
            }
            if (!complex && dtype == Axml.T_STRING && data >= 0 && data < global.length) {
                String s = global[data];
                if (!en.strings.contains(s)) en.strings.add(s);
            }
        }
    }
}
