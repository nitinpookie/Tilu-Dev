package com.chanit.featuremerger;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.chanit.featuremerger.core.Merger;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.VpnTransplant;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** VPN tab: pick the VPN app and the game, scan, transplant, verify, save the unsigned result. */
final class TransplantController {
    private static final Pattern PKG = Pattern.compile("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$");
    private static final Pattern FF = Pattern.compile("(?i)freefire|garena|\\.dts\\.");

    private final MainActivity a;
    private final MaterialAutoCompleteTextView ddVpn, ddGame;
    private final LinearLayout refsHost;
    private final EditText etExtra;
    private final MaterialSwitch swText, swInject;
    private final MaterialButton btnScan, btnGo, btnSave, btnShare, btnReport, btnAddVpn, btnAddGame;
    private final View cardProgress, cardResult;
    private final TextView tvScan, tvStep, tvTail, tvResult;
    private final LinearProgressIndicator bar;

    private Model.Apk vpn, game;
    private VpnTransplant.Scan scan;
    private final List<MaterialCheckBox> refBoxes = new ArrayList<>();
    private final List<String> refNames = new ArrayList<>();
    private final ArrayList<String> tail = new ArrayList<>();
    private boolean busy;
    private File lastOut;
    private String lastReport = "";

    TransplantController(MainActivity act) {
        a = act;
        ddVpn = a.findViewById(R.id.ddVpn);
        ddGame = a.findViewById(R.id.ddGame);
        refsHost = a.findViewById(R.id.refsHost);
        etExtra = a.findViewById(R.id.etExtra);
        swText = a.findViewById(R.id.swText);
        swInject = a.findViewById(R.id.swInject);
        btnScan = a.findViewById(R.id.btnScan);
        btnGo = a.findViewById(R.id.btnGo);
        btnSave = a.findViewById(R.id.btnSave);
        btnShare = a.findViewById(R.id.btnShare);
        btnReport = a.findViewById(R.id.btnReport);
        btnAddVpn = a.findViewById(R.id.btnAddVpn);
        btnAddGame = a.findViewById(R.id.btnAddGame);
        cardProgress = a.findViewById(R.id.cardProgress);
        cardResult = a.findViewById(R.id.cardResult);
        tvScan = a.findViewById(R.id.tvScan);
        tvStep = a.findViewById(R.id.tvStep);
        tvTail = a.findViewById(R.id.tvTail);
        tvResult = a.findViewById(R.id.tvResult);
        bar = a.findViewById(R.id.barBuild);

        // the last entry of each dropdown is "add an app", so the list is never empty
        ddVpn.setOnItemClickListener((p, v, i, id) -> {
            if (i >= 0 && i < a.apks.size()) pickVpn(a.apks.get(i));
            else {
                ddVpn.setText(vpn == null ? "" : name(vpn), false);
                a.openAddSheet(MainActivity.ROLE_VPN);
            }
        });
        ddGame.setOnItemClickListener((p, v, i, id) -> {
            if (i >= 0 && i < a.apks.size()) game = a.apks.get(i);
            else {
                ddGame.setText(game == null ? "" : name(game), false);
                a.openAddSheet(MainActivity.ROLE_GAME);
            }
        });
        btnAddVpn.setOnClickListener(v -> a.openAddSheet(MainActivity.ROLE_VPN));
        btnAddGame.setOnClickListener(v -> a.openAddSheet(MainActivity.ROLE_GAME));
        btnScan.setOnClickListener(v -> runScan());
        btnGo.setOnClickListener(v -> go());
        btnSave.setOnClickListener(v -> {
            if (lastOut != null) a.saver.launch(lastOut.getName());
        });
        btnShare.setOnClickListener(v -> share());
        btnReport.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("report", lastReport));
            Toast.makeText(a, "Report copied. Paste it to Claude.", Toast.LENGTH_SHORT).show();
        });
        refresh();
    }

    private static String name(Model.Apk x) { return x.label + (x.vpn ? "  [VPN]" : ""); }

    void refresh() {
        String[] names = new String[a.apks.size() + 1];
        for (int i = 0; i < a.apks.size(); i++) names[i] = name(a.apks.get(i));
        names[a.apks.size()] = "+  Add app (installed apps / files)";
        ddVpn.setSimpleItems(names);
        ddGame.setSimpleItems(names);
        if (vpn != null && !a.apks.contains(vpn)) vpn = null;
        if (game != null && !a.apks.contains(game)) game = null;
        if (vpn == null) for (Model.Apk x : a.apks) if (x.vpn) { vpn = x; break; }
        if (vpn == null && !a.apks.isEmpty()) vpn = a.apks.get(0);
        if (game == null) for (Model.Apk x : a.apks) if (x != vpn && !x.vpn) { game = x; break; }
        if (game == null) for (Model.Apk x : a.apks) if (x != vpn) { game = x; break; }
        ddVpn.setText(vpn == null ? "" : name(vpn), false);
        ddGame.setText(game == null ? "" : name(game), false);
        if (vpn == null) {
            scan = null;
            refsHost.removeAllViews();
            tvScan.setText("Tap \"Add VPN app\" above to choose it from your installed apps or files.");
        }
    }

    /** An APK was just added from the picker for a slot: put it straight into that slot. */
    void assign(int role, Model.Apk x) {
        if (x == null) return;
        if (role == MainActivity.ROLE_VPN) pickVpn(x);
        else if (role == MainActivity.ROLE_GAME) {
            game = x;
            ddGame.setText(name(x), false);
        } else select(x);
    }

    /** Called from the Apps tab: use this APK as the VPN (if it is one) or as the game. */
    void select(Model.Apk x) {
        if (x.vpn) pickVpn(x);
        else {
            game = x;
            ddGame.setText(name(x), false);
        }
    }

    private void pickVpn(Model.Apk x) {
        vpn = x;
        scan = null;
        refBoxes.clear();
        refNames.clear();
        refsHost.removeAllViews();
        ddVpn.setText(name(x), false);
        tvScan.setText("Tap \"Scan VPN\" to see how this VPN picks its games.");
    }

    // ------------------------------------------------------------------ scan
    private void runScan() {
        if (busy) return;
        if (vpn == null) {
            Toast.makeText(a, "Choose the VPN app first", Toast.LENGTH_SHORT).show();
            return;
        }
        busy = true;
        btnScan.setEnabled(false);
        btnGo.setEnabled(false);
        tvScan.setText("Scanning " + vpn.label + " ...");
        final Model.Apk target = vpn;
        a.exec.execute(() -> {
            try {
                VpnTransplant.Scan s = VpnTransplant.scan(a, new File(target.path), new Merger.Sink() {
                    @Override public void step(int pct, String msg) { }
                    @Override public void log(String line) { a.log(line); }
                });
                a.ui.post(() -> showScan(target, s, null));
            } catch (Throwable t) {
                a.log("SCAN FAILED: " + t);
                a.ui.post(() -> showScan(target, null, t));
            }
        });
    }

    private void showScan(Model.Apk target, VpnTransplant.Scan s, Throwable err) {
        busy = false;
        btnScan.setEnabled(true);
        btnGo.setEnabled(true);
        if (target != vpn) return;
        refsHost.removeAllViews();
        refBoxes.clear();
        refNames.clear();
        if (err != null || s == null) {
            scan = null;
            tvScan.setText("Scan failed: " + err + "\nSee the Log tab.");
            return;
        }
        scan = s;
        tvScan.setText(s.summary());
        boolean anyGame = false;
        for (String p : s.packages) if (FF.matcher(p).find()) anyGame = true;
        for (String p : s.packages) {
            MaterialCheckBox cb = new MaterialCheckBox(a);
            cb.setText(p);
            cb.setChecked(!anyGame || FF.matcher(p).find());
            refsHost.addView(cb);
            refBoxes.add(cb);
            refNames.add(p);
        }
    }

    // ------------------------------------------------------------------ transplant
    private void go() {
        if (busy) return;
        if (vpn == null || game == null) {
            Toast.makeText(a, "Choose the VPN app and the game", Toast.LENGTH_SHORT).show();
            return;
        }
        if (vpn == game) {
            Toast.makeText(a, "VPN and game must be different apps", Toast.LENGTH_SHORT).show();
            return;
        }
        final VpnTransplant.Plan p = new VpnTransplant.Plan();
        p.vpn = vpn;
        p.patchText = swText.isChecked();
        p.injectIfMissing = swInject.isChecked();
        Set<String> targets = new LinkedHashSet<>();
        if (game.pkg != null && !"unknown".equals(game.pkg)) targets.add(game.pkg);
        String extra = etExtra.getText() == null ? "" : etExtra.getText().toString();
        for (String t : extra.split("[,\\s;]+")) {
            String x = t.trim();
            if (x.isEmpty()) continue;
            if (!PKG.matcher(x).matches()) {
                Toast.makeText(a, "Not a package name: " + x, Toast.LENGTH_LONG).show();
                return;
            }
            targets.add(x);
        }
        for (int i = 0; i < refBoxes.size(); i++) if (refBoxes.get(i).isChecked()) p.refs.add(refNames.get(i));
        p.refs.removeAll(targets);
        p.targets.addAll(targets);
        if (p.targets.isEmpty()) {
            Toast.makeText(a, "No package name to add", Toast.LENGTH_SHORT).show();
            return;
        }

        busy = true;
        btnGo.setEnabled(false);
        btnScan.setEnabled(false);
        cardResult.setVisibility(View.GONE);
        cardProgress.setVisibility(View.VISIBLE);
        tail.clear();
        tvTail.setText("");
        bar.setProgress(0);
        tvStep.setText("Starting");
        a.log("---- VPN transplant: " + vpn.label + " + " + p.targets + " ----");

        a.exec.execute(() -> {
            try {
                VpnTransplant.Result r = VpnTransplant.run(a, p, new Merger.Sink() {
                    @Override public void step(int pct, String msg) {
                        a.ui.post(() -> {
                            bar.setProgress(pct);
                            tvStep.setText(msg);
                        });
                        a.log(msg);
                    }

                    @Override public void log(String line) {
                        a.ui.post(() -> {
                            tail.add(line);
                            while (tail.size() > 6) tail.remove(0);
                            StringBuilder tb = new StringBuilder();
                            for (String t : tail) tb.append(t).append('\n');
                            tvTail.setText(tb.toString().trim());
                        });
                        a.log(line);
                    }
                });
                a.log(r.report);
                a.ui.post(() -> finish(r));
            } catch (Throwable t) {
                VpnTransplant.Result r = new VpnTransplant.Result();
                r.ok = false;
                r.report = VpnTransplant.errorReport(a, p, t);
                a.log("TRANSPLANT FAILED:\n" + r.report);
                a.ui.post(() -> finish(r));
            }
        });
    }

    private void finish(VpnTransplant.Result r) {
        busy = false;
        btnGo.setEnabled(true);
        btnScan.setEnabled(true);
        cardProgress.setVisibility(View.GONE);
        cardResult.setVisibility(View.VISIBLE);
        lastOut = r.ok ? r.out : null;
        lastReport = r.report;
        int vis = lastOut != null ? View.VISIBLE : View.GONE;
        btnSave.setVisibility(vis);
        btnShare.setVisibility(vis);
        StringBuilder sb = new StringBuilder();
        if (lastOut != null)
            sb.append(String.format(Locale.US, "Saved (unsigned): %s  (%.1f MB)\n\"Save as\" puts it in a folder you choose, then sign it with MT Manager.\n\n",
                    lastOut.getName(), lastOut.length() / 1048576.0));
        sb.append(r.report);
        tvResult.setText(sb.toString());
    }

    // ------------------------------------------------------------------ save / share
    void copyTo(Uri u) {
        if (lastOut == null) return;
        try (InputStream in = new FileInputStream(lastOut); OutputStream o = a.getContentResolver().openOutputStream(u)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while (o != null && (n = in.read(buf)) > 0) o.write(buf, 0, n);
            a.ui.post(() -> Toast.makeText(a, "Saved. Now sign it with MT Manager.", Toast.LENGTH_LONG).show());
        } catch (Throwable t) {
            a.log("Save failed: " + t);
            a.ui.post(() -> Toast.makeText(a, "Save failed: " + t.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void share() {
        if (lastOut == null) return;
        Uri u = FileProvider.getUriForFile(a, a.getPackageName() + ".files", lastOut);
        Intent i = new Intent(Intent.ACTION_SEND)
                .setType("application/vnd.android.package-archive")
                .putExtra(Intent.EXTRA_STREAM, u)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        a.startActivity(Intent.createChooser(i, "Share patched APK (unsigned)"));
    }
}
